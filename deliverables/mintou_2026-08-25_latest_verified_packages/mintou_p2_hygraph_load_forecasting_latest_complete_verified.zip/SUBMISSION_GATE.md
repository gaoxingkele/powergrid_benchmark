# Submission gate: mintou_p2_hygraph_load_forecasting

Status: **AUTHOR SIGN-OFF REQUIRED BEFORE SUBMISSION**

The archive is complete and mechanically verified, but it must not be uploaded until all author-controlled declarations are resolved. No author identity, affiliation, CRediT role, funding statement, conflict statement, ORCID, repository DOI, or AI-use disclosure has been guessed.

## Unresolved author-controlled fields in canonical LaTeX

- Line 655: {[}AUTHOR INPUT REQUIRED: assign verified CRediT roles to Jieyun Zheng, Linyao Zhang, Zhanghuang Zhang, Zhuolin Chen, and Ying Shi; obtain every author's approval; and insert the author-approved responsibility statement.{]}
- Line 659: {[}AUTHOR INPUT REQUIRED: insert the verified funder, grant number, and APC funder, or state ``This research received no external funding.''{]}
- Line 671: All datasets used in this study are public: the Open Power System Data 60 min package (https://open-power-system-data.org) \cite{ref29}, SimBench load profiles (https://simbench.de) \cite{ref30}, and Ausgrid solar-home electricity data (https://www.ausgrid.com.au) \cite{ref24}. The supplementary package contains the CSA-LoadNet implementation and configurations; 280 fixed-split non-hierarchical decision-set records; 440 exact-hierarchy model--reconciliation records; and the accepted rolling-origin evidence comprising 240 method--block--seed rows, 6,750 date-aggregated forecast-target audit rows, block-level inference, and a validation report. {[}AUTHOR INPUT REQUIRED: confirm the package-access wording and deposit a persistent public archive before adding a repository URL or DOI.{]} No persistent public archive is verified in the current evidence.
- Line 675: {[}AUTHOR INPUT REQUIRED: confirm the final acknowledgment and venue-compliant generative-AI disclosure, including the tool, purposes, author review, and responsibility statement.{]} The internal preparation record indicates use of Claude (Anthropic) for language drafting and editing and for assistance with analysis and figure-generation code, but author approval of the submission wording is not verified in this worktree.
- Line 679: {[}AUTHOR INPUT REQUIRED: insert the author-confirmed conflict-of-interest statement.{]}

## Final manual actions

- Confirm author list, affiliations, correspondence, CRediT roles, and author approval.
- Confirm funding/APC funding, acknowledgments, conflicts of interest, ethics wording, and generative-AI disclosure.
- Deposit the code/data supplement in a persistent archive where the manuscript requires a public URL or DOI.
- Re-check the live target-journal instructions and upload fields immediately before submission.
