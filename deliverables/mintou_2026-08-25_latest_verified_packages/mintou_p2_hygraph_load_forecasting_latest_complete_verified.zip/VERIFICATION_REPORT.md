# Verification report: mintou_p2_hygraph_load_forecasting

- Target journal: Electronics
- Canonical source: `paper_projects/mintou_p2_hygraph_load_forecasting/manuscript/journal_submission/paper.tex`
- Canonical source SHA-256: `813FF073746279C928621E7C4C2BE6E2F80491EBFCDF54A3C3ED1FABA3839F87`
- Isolated LaTeX build: PASS (25 pages; PDF SHA-256 `74B7F932A626E63FFBA2A0B45D2C93C74C5B16CBA9F209535B9420831820ABD4`)
- Scientific evidence-contract check: PASS
- Shared regression tests: PASS
- Package status: PASS_WITH_AUTHOR_GATES
- Submission ready: false

## Material counts

- latex_files: 43
- pdf_files: 1
- figure_files: 31
- table_files: 9
- experiment_files: 14
- evidence_data_files: 56
- code_files: 41
- review_provenance_files: 53

## LaTeX checks

- Abstract words: 199
- Figure inclusions resolved: 8/8
- Missing labels: 0
- Missing bibliography keys: 0
- Author-controlled gates: 5

## Scope note

This report verifies compilation, internal LaTeX references, material presence, evidence-contract scaffolding, and archive integrity. It does not make a final scientific judgment for the authors and does not replace live journal-policy checks, plagiarism screening, or author sign-off.
