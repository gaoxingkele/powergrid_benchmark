# Verification report: mintou_p1_dstar_gru_dispatch

- Target journal: IEEE Access
- Canonical source: `paper_projects/mintou_p1_dstar_gru_dispatch/manuscript/journal_submission/paper.tex`
- Canonical source SHA-256: `75BAE6711A88DE12F41BD72B6B74E5AE2FD343C9B283C41DE16EFBDB747A373B`
- Isolated LaTeX build: PASS (12 pages; PDF SHA-256 `FFA6342D16BFD95046B42BDA2093AAE14E249A83935A2F72EAE6B56A0E52F83F`)
- Scientific evidence-contract check: PASS
- Shared regression tests: PASS
- Package status: PASS_WITH_AUTHOR_GATES
- Submission ready: false

## Material counts

- latex_files: 81
- pdf_files: 1
- figure_files: 25
- table_files: 5
- experiment_files: 22
- evidence_data_files: 32
- code_files: 41
- review_provenance_files: 52

## LaTeX checks

- Abstract words: 249
- Figure inclusions resolved: 5/5
- Missing labels: 0
- Missing bibliography keys: 0
- Author-controlled gates: 8

## Scope note

This report verifies compilation, internal LaTeX references, material presence, evidence-contract scaffolding, and archive integrity. It does not make a final scientific judgment for the authors and does not replace live journal-policy checks, plagiarism screening, or author sign-off.
