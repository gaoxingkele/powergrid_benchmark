# Submission gate: mintou_p1_dstar_gru_dispatch

Status: **AUTHOR SIGN-OFF REQUIRED BEFORE SUBMISSION**

The archive is complete and mechanically verified, but it must not be uploaded until all author-controlled declarations are resolved. No author identity, affiliation, CRediT role, funding statement, conflict statement, ORCID, repository DOI, or AI-use disclosure has been guessed.

## Unresolved author-controlled fields in canonical LaTeX

- Line 13: \address[1]{[AUTHOR INPUT REQUIRED: complete institutional addresses]}
- Line 16: \corresp{Corresponding author: [AUTHOR INPUT REQUIRED: name and e-mail].}
- Line 424: {[}AUTHOR INPUT REQUIRED: confirm the final acknowledgment and venue-compliant generative-AI disclosure. The preparation record indicates AI-assisted drafting and code support, but the submitting authors must verify the tools, purposes, and responsibility statement.{]}
- Line 428: {[}AUTHOR INPUT REQUIRED: insert the funder and grant number, or explicitly state that the work received no external funding.{]}
- Line 436: The executed study uses public synthetic power-system data and does not involve human participants, animals, or personal data. {[}AUTHOR INPUT REQUIRED: confirm the venue-specific ethics wording.{]}
- Line 440: {[}AUTHOR INPUT REQUIRED: provide a CRediT contribution statement. Contributions cannot be inferred from repository history.{]}
- Line 444: {[}AUTHOR INPUT REQUIRED: confirm the conflicts-of-interest statement.{]}
- Line 482: {[}AUTHOR INPUT REQUIRED: add an IEEE Access short biography and photograph for every author after the references.{]}

## Final manual actions

- Confirm author list, affiliations, correspondence, CRediT roles, and author approval.
- Confirm funding/APC funding, acknowledgments, conflicts of interest, ethics wording, and generative-AI disclosure.
- Deposit the code/data supplement in a persistent archive where the manuscript requires a public URL or DOI.
- Re-check the live target-journal instructions and upload fields immediately before submission.
