# Verification report: mintou_p6_bilonsga_project_review

- Target journal: Applied Sciences
- Canonical source: `paper_projects/mintou_p6_bilonsga_project_review/manuscript/journal_submission/paper.tex`
- Canonical source SHA-256: `CC28621120D25C6CEC611BD93828447B0C42290FDFB1CA1B8AC6181C595C6943`
- Isolated LaTeX build: PASS (29 pages; PDF SHA-256 `3CFC3CEC321E429F2FD103E810B898EC5CE8F6CE390298F52A5E30A15A2C92D2`)
- Scientific evidence-contract check: PASS
- Shared regression tests: PASS
- Package status: PASS_WITH_AUTHOR_GATES
- Submission ready: false

## Material counts

- latex_files: 41
- pdf_files: 1
- figure_files: 29
- table_files: 13
- experiment_files: 20
- evidence_data_files: 31
- code_files: 41
- review_provenance_files: 54

## LaTeX checks

- Abstract words: 200
- Figure inclusions resolved: 9/9
- Missing labels: 0
- Missing bibliography keys: 0
- Author-controlled gates: 2

## Scope note

This report verifies compilation, internal LaTeX references, material presence, evidence-contract scaffolding, and archive integrity. It does not make a final scientific judgment for the authors and does not replace live journal-policy checks, plagiarism screening, or author sign-off.
