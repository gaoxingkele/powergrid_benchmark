# Submission gate: mintou_p6_bilonsga_project_review

Status: **AUTHOR SIGN-OFF REQUIRED BEFORE SUBMISSION**

The archive is complete and mechanically verified, but it must not be uploaded until all author-controlled declarations are resolved. No author identity, affiliation, CRediT role, funding statement, conflict statement, ORCID, repository DOI, or AI-use disclosure has been guessed.

## Unresolved author-controlled fields in canonical LaTeX

- Line 795: {[}AUTHOR INPUT REQUIRED: assign the CRediT roles to Yubin Lin, Jingbo Zhang, Xiaoyu Huang, Dishan Yang, and Jiyu Li, and obtain approval from every author.{]} All authors have read and agreed to the published version of the manuscript.
- Line 799: {[}AUTHOR INPUT REQUIRED: insert the verified funder, grant number, and APC funder, or state ``This research received no external funding.''{]}

## Final manual actions

- Confirm author list, affiliations, correspondence, CRediT roles, and author approval.
- Confirm funding/APC funding, acknowledgments, conflicts of interest, ethics wording, and generative-AI disclosure.
- Deposit the code/data supplement in a persistent archive where the manuscript requires a public URL or DOI.
- Re-check the live target-journal instructions and upload fields immediately before submission.
