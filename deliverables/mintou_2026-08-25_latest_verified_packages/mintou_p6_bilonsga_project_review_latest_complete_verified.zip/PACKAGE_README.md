# mintou_p6_bilonsga_project_review: latest complete verified package

Canonical manuscript source: `01_manuscript/latex/paper.tex`  
Fresh PDF compiled from that exact source: `01_manuscript/pdf/paper.pdf`

The package deliberately excludes the older `paper.pdf` and `paper_narrative_revision.pdf` files from the working tree. The only primary manuscript PDF is the fresh isolated build above. `06_review_provenance/project_snapshot/manuscript/MANUSCRIPT.md`, when present, is a legacy Markdown working snapshot and is **not** the canonical source.

Contents:

- `01_manuscript/`: canonical LaTeX, journal class/template dependencies, referenced figures, and the freshly compiled PDF.
- `02_figures_tables/`: source figures and derived tables.
- `03_experiments/`: project-local experiment scripts, configs, logs, and outputs when present.
- `04_evidence_data/`: evidence runs, source data, result tables, manifests, and provenance.
- `05_code/`: paper scaffold, shared Mintou implementation modules, workflow scripts, tests, and environment metadata.
- `06_review_provenance/`: revision records, trace/logic material, manuscript working snapshot, portfolio audits, and reference-audit summary.
- `VERIFICATION_REPORT.*`: compilation and completeness results.
- `SUBMISSION_GATE.md`: author-controlled items that still block upload.
- `SHA256SUMS.txt`: SHA-256 for every payload file except the checksum file itself.

Package status: **PASS_WITH_AUTHOR_GATES**. This is an internal complete package, not an editorial acceptance guarantee. Read `SUBMISSION_GATE.md` before any upload.
