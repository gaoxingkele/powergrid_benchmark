# Verification report: mintou_p3_samode_distribution_planning

- Target journal: Energies
- Canonical source: `paper_projects/mintou_p3_samode_distribution_planning/manuscript/journal_submission/paper.tex`
- Canonical source SHA-256: `CB1EAD007099901B7C8A29FDC5278A11BB1CD57EE82DC184772AF0629B2080E5`
- Isolated LaTeX build: PASS (29 pages; PDF SHA-256 `7594F9994F9BBC0C965269C25BB3895EC4F9CC181F83E7FED52978D6D1610DDF`)
- Scientific evidence-contract check: PASS
- Shared regression tests: PASS
- Package status: PASS_WITH_AUTHOR_GATES
- Submission ready: false

## Material counts

- latex_files: 34
- pdf_files: 1
- figure_files: 22
- table_files: 11
- experiment_files: 0
- evidence_data_files: 37
- code_files: 41
- review_provenance_files: 92

## LaTeX checks

- Abstract words: 163
- Figure inclusions resolved: 9/9
- Missing labels: 0
- Missing bibliography keys: 0
- Author-controlled gates: 2

## Scope note

This report verifies compilation, internal LaTeX references, material presence, evidence-contract scaffolding, and archive integrity. It does not make a final scientific judgment for the authors and does not replace live journal-policy checks, plagiarism screening, or author sign-off.
