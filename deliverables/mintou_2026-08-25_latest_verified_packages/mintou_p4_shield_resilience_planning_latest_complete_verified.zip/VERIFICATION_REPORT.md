# Verification report: mintou_p4_shield_resilience_planning

- Target journal: Energies
- Canonical source: `paper_projects/mintou_p4_shield_resilience_planning/manuscript/journal_submission/paper.tex`
- Canonical source SHA-256: `AAE247D26B6D3DA32F92B357ECB64056BEED80D0E58ACFF9AABFB9273D57E3DF`
- Isolated LaTeX build: PASS (28 pages; PDF SHA-256 `327F49247E74137E067E84CDFD434214EA0288EB5CA7FD28E707746D875FF764`)
- Scientific evidence-contract check: PASS
- Shared regression tests: PASS
- Package status: PASS_WITH_AUTHOR_GATES
- Submission ready: false

## Material counts

- latex_files: 37
- pdf_files: 1
- figure_files: 24
- table_files: 7
- experiment_files: 4
- evidence_data_files: 30
- code_files: 41
- review_provenance_files: 67

## LaTeX checks

- Abstract words: 176
- Figure inclusions resolved: 9/9
- Missing labels: 0
- Missing bibliography keys: 0
- Author-controlled gates: 4

## Scope note

This report verifies compilation, internal LaTeX references, material presence, evidence-contract scaffolding, and archive integrity. It does not make a final scientific judgment for the authors and does not replace live journal-policy checks, plagiarism screening, or author sign-off.
