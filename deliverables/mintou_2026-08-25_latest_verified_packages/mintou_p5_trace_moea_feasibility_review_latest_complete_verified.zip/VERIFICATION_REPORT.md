# Verification report: mintou_p5_trace_moea_feasibility_review

- Target journal: Energies
- Canonical source: `paper_projects/mintou_p5_trace_moea_feasibility_review/manuscript/journal_submission/paper.tex`
- Canonical source SHA-256: `C454A3FF9B2A11CB912E410CAF94B775A08A90E5C40851C747D5B2AAE0AC9529`
- Isolated LaTeX build: PASS (28 pages; PDF SHA-256 `2312873685CADDFC8300E1746DABD569DED69593015FEA4D684190592FF93705`)
- Scientific evidence-contract check: PASS
- Shared regression tests: PASS
- Package status: PASS_WITH_AUTHOR_GATES
- Submission ready: false

## Material counts

- latex_files: 38
- pdf_files: 1
- figure_files: 26
- table_files: 14
- experiment_files: 74
- evidence_data_files: 40
- code_files: 41
- review_provenance_files: 52

## LaTeX checks

- Abstract words: 169
- Figure inclusions resolved: 8/8
- Missing labels: 0
- Missing bibliography keys: 0
- Author-controlled gates: 2

## Scope note

This report verifies compilation, internal LaTeX references, material presence, evidence-contract scaffolding, and archive integrity. It does not make a final scientific judgment for the authors and does not replace live journal-policy checks, plagiarism screening, or author sign-off.
