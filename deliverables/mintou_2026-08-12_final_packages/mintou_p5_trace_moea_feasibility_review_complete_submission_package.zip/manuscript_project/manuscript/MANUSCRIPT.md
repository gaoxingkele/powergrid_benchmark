<!-- MDPI Energies submission manuscript.
     Paper ID: mintou_p5 (TRACE-MOEA)
     Section: Electrical Power and Energy Systems
     All quantitative claims verified on 2026-07-16 against evidence files at:
       papers/mintou/mintou_p5_trace_moea_feasibility_review/evidence/tables/real_project_review_leaderboard.csv
       papers/mintou/mintou_p5_trace_moea_feasibility_review/evidence/tables/real_project_review_significance.csv
       papers/mintou/mintou_p5_trace_moea_feasibility_review/evidence/tables/real_nerc_rule_backtest.csv
       papers/mintou/mintou_p5_trace_moea_feasibility_review/evidence/tables/real_mtep_backtest.csv
       papers/mintou/mintou_p5_trace_moea_feasibility_review/evidence/tables/real_budget_sensitivity_075x.csv
       papers/mintou/mintou_p5_trace_moea_feasibility_review/evidence/tables/real_budget_sensitivity_075x_significance.csv
       papers/mintou/mintou_p5_trace_moea_feasibility_review/src/configs/real_project_review_config.json
     Figures: ./figures/ (print-resolution PNG plus PDF/SVG evidence figures;
     regenerate Figures 1--3 and 5 with figures/make_figures.py and Figure 4 with
     scripts/mintou/generate_evidence_gap_figures.py)
     Naming policy: the mechanism is described as "preference-adaptive" throughout;
     no "coevolution" terminology is used, consistent with ROUND2_REVIEW.md finding CL2.
     All AUTHOR INPUT REQUIRED markers below must be completed before submission. -->

# TRACE-MOEA: A Preference-Adaptive Evolutionary Algorithm with Decision Trace Archives for Investment-Effectiveness Review of Power Grid Projects

**Authors:** Yubin Lin (林宇彬), Jiyu Li (李继宇), Xiaofei Ruan (阮筱菲), Xiaoyu Huang (黄晓予), Dishan Yang (杨迪珊)
**Affiliations:** Economic and Technological Research Institute of State Grid Fujian Electric Power Co., Ltd., Fuzhou 350000, Fujian, China
**Correspondence:** 18606932711@163.com (Y. Lin)

## Abstract

Utilities reviewing large grid-project queues need portfolio-aware optimization without losing decision traceability. TRACE-MOEA combines preference-adaptive ranking, deterministic budget repair, and a quarantined archive that records repair drops and preference-elite injections without entering the evaluation metric. On a reproducible five-objective benchmark of 120 candidate projects, the method reaches pooled mean hypervolume 0.17425 across seven review scenarios and 30 seeds per stochastic method. It is 0.89% above NSGA-II (0.17270). Among 28 comparisons with four stochastic baselines, TRACE-MOEA has 27 positive mean differences and 24 Holm-significant wins, with no significant loss. Twenty-one gaps against three deterministic ranking rules are reported descriptively and all favor TRACE-MOEA. A separate 270-run budget scan finds higher hypervolume than R-NSGA-II and NSGA-II at all three tested budgets. Component attribution remains conservative: preference adaptation contributes 0.17% in the pooled summary but is not significant after a cross-scenario correction. The archive provides event provenance for audit rather than metric improvement. Public reliability and project-outcome checks provide descriptive external consistency, not validated human-review performance. The released artifact contains the candidate derivation, implementation, configurations, statistical comparisons, and 3360 main-run records.

**Keywords:** power grid investment review; project portfolio selection; multi-objective evolutionary algorithm; preference adaptation; decision traceability; hypervolume; external validity backtest

---

## 1. Introduction

Grid operators face more candidate investments than available capital can support. The queue includes line reinforcement, protection and automation retrofits, storage, and renewable-support installations. Expansion-planning research offers mature tools for sizing and routing assets under uncertainty [1,2]. A review board faces a different task: select from predefined projects under a budget, balance reliability, renewable accommodation, and schedule risk, and justify each inclusion to regulators and stakeholders.

The instruments that boards actually use come from multi-criteria decision analysis (MCDA). The AHP and TOPSIS families dominate energy investment appraisal [3,4] and continue to be refined for grid asset prioritization at this journal [5]. Their strength is procedural transparency: weights, pairwise judgments, and closeness scores can all be minuted. Their structural weakness is independent project scoring, which overlooks budget crowding-out and portfolio-level trade-offs. Exact portfolio methods such as Robust Portfolio Modeling address this issue for small pools [6,7], but richer dependencies and larger combinatorial pools can make them computationally difficult. MOEAs offer scalable approximate search [8,9], although a converged front alone does not explain why a project appears in a recommendation.

TRACE-MOEA is designed to produce both portfolios and review evidence. A preference-adaptive layer maintains objective-weight vectors and injects their best-response portfolios as elites. Every five generations, the vectors are perturbed and retained according to the dispersion of their induced responses. Deterministic repair removes low-benefit selections until the budget is met. A quarantined archive timestamps repair drops and preference-elite injections; no trace statistic enters an objective, constraint, or selection decision.

Because genuine utility review records with feasibility labels are confidential, evaluation is conducted on a reproducible proxy benchmark. The pool of 120 projects is generated by published deterministic rules from RTS-GMLC zones, SimBench networks, and metadata from 40 cached public NERC reliability reports. Seven scenarios cover portfolio optimization, distribution-only review, reliability and renewable preferences, budget tightening, preference-aware support, and traceability. A five-objective formulation encodes the investment-effectiveness lens. A two-rung external-consistency ladder then checks the selected portfolios against a NERC-derived rule and against historical MISO MTEP16 project outcomes.

The contributions of this paper, each tied to its supporting evidence (detailed in Sections 4–6), are as follows:

1. **A preference-adaptive, repair-equipped, trace-archiving MOEA for grid project review.** The adaptive weight-vector population, the benefit–cost repair operator, and the quarantined decision archive are individually switchable components on a standard constrained non-dominated sorting kernel. The archive covers on average 98.6% of projects in the returned front with at least one logged decision event. Archive variables are quarantined from the metric and selection rule (evidence: `real_project_review_leaderboard.csv`, trace columns).

2. **A reproducible five-objective public benchmark for investment-effectiveness review.** 120 candidates in six archetypes, derived deterministically from three public data sources, with full generation code released. The candidate-derivation pipeline is shared with a companion study of a methodologically different algorithm (BiLo-NSGA [28]) and this sharing is declared explicitly in the Data Availability statement (evidence: `real_project_review_source_profile.csv`; configuration in `real_project_review_config.json`).

3. **A statistically disciplined result with a direct preference-based comparator.** Under 30 seeds per stochastic method and scenario, fixed method-independent normalization, and Holm-corrected Mann--Whitney tests, TRACE-MOEA reaches pooled mean hypervolume 0.17425, +0.89% over NSGA-II. It records 24 significant wins among 28 stochastic-baseline comparisons and no significant loss; 21 deterministic-rule gaps are kept descriptive. R-NSGA-II [13] supplies a direct reference-point control, and a separate three-budget scan tests hypervolume and preference-achievement distance. The preference layer's isolated pooled contribution is only +0.17%, and its full-versus-ablation comparison is not significant after correction across scenarios.

4. **A two-rung external-consistency ladder with bounded conclusions.** On the NERC rule backtest, the method's portfolios oversample documented-risk candidates (priority capture 1.34–1.55). On the MISO MTEP16 outcome backtest, broad capture is 1.070–1.079 and the raw point-biserial association is 0.151–0.169. These project-level p-values are treated as nominal diagnostics because selections are portfolio-dependent and the backtest comparisons were not covered by a constrained permutation family. AHP-TOPSIS or Weighted Sum attains comparable or higher capture on individual views, so no best-alignment or review-validity claim is made.

Two boundaries frame the contribution. First, the preference-adaptive layer has an auxiliary role: its isolated pooled difference is 0.17%, and no direct ablation contrast remains significant after correction across scenarios. The layer contributes preference-labeled archive events, but its optimization benefit is unresolved (Section 6.2).

Second, repair guarantees benchmark-budget feasibility and sub-second runtimes make seed ensembles inexpensive. Each recommended project also carries a machine-readable record of preference protection and competing repair drops. Whether that record improves contested human decisions remains untested.

Section 2 situates the work in three literatures. Section 3 defines the problem and the public benchmark. Section 4 details the algorithm. Section 5 describes the experimental protocol, Section 6 the results, Section 7 the discussion, Section 8 the limitations, and Section 9 concludes.

---

## 2. Related Work

Three research threads intersect in this work: investment portfolio decision methods for power grids, preference-guided evolutionary multi-objective optimization, and the traceability of algorithmic decisions.

### 2.1. Grid Investment Decisions: Optimization and Review Scoring

Transmission expansion planning treats the network topology itself as the decision variable and has been surveyed comprehensively from both the modeling [1] and the practice side [2]; stochastic engineering-economic formulations bring market and regulatory uncertainty into the objective [10]. The present work addresses a different sub-problem: selecting from a pre-specified list of candidate projects under a hard budget, which is the institutional form of most utility investment cycles.

For this sub-problem, the energy-domain literature relies heavily on MCDA. The surveys of Wang et al. [3] and Kumar et al. [4] document the use of AHP and TOPSIS across energy investment appraisal tasks, and this tradition remains active: recent studies combine fuzzy-AHP with distribution-transformer maintenance priorities [5] and explainable multi-criteria scoring with strategic energy-investment ranking [33]. Portfolio-explicit alternatives exist in operational research. Robust Portfolio Modeling (RPM) computes non-dominated project portfolios under incomplete preference information [6] and has been applied to infrastructure maintenance programming [7].

Recent power-system planning studies have strengthened the application layer through coordinated transmission-storage planning [29], interruption-cost estimation for reliability investment [30], grid-side storage investment-return analysis [31], and hybrid exact-heuristic treatment of non-analytical investment costs [32]. These studies provide increasingly detailed engineering or economic validation, but they optimize system expansion or asset configuration rather than an auditable review of a large, pre-specified project queue. Hybrid grid-investment models also couple risk and benefit dimensions using MCDA fronts [11]. The remaining gap is therefore not portfolio optimization alone. It is the combination of portfolio-level search over more than one hundred candidates, online preference adaptation, active budget repair, and an exported decision record that can be inspected independently of the optimization metric.

### 2.2. Preference-Guided Evolutionary Multi-Objective Optimization

Dominance-based MOEAs [8] and decomposition-based ones [9,12] treat all trade-off directions as equally interesting, which motivated two decades of research on preference injection into evolutionary multi-objective optimization. Representative approaches include reference-point guidance [13], achievement-scalarizing function methods [14], preference-modified dominance relations [15], and comprehensive taxonomies of a priori, interactive, and a posteriori preference articulation [16,17].

Two developments in this thread are particularly relevant to the present design. RVEA demonstrated that reference vectors can be adapted during the run to the geometry of the objective space [18], establishing run-time preference adaptation as a legitimate mechanism — though on continuous benchmarks with no constraint repair and no decision recording. The second relevant development is the field's own empirical auditing of preference guidance. Li et al. [19] showed that measuring preference-based EMO fairly is itself a hard problem, and a subsequent holistic empirical study found that reference-point guidance can degrade search performance on some problem classes [20]. The present results extend that caution to a constrained binary portfolio problem: we find, and report, that the preference-adaptive layer contributes only weakly on top of a well-repaired constrained kernel. What no existing work in this thread provides is the specific combination we require: adaptive preference structure on a budget-repaired combinatorial problem, with the preference decisions archived for downstream review rather than discarded after optimization.

### 2.3. Traceability and Explainability of Algorithmic Decisions

The explainable AI (XAI) literature has matured a vocabulary of transparency and post-hoc explanation [21] and an account of what human decision-makers accept as explanations [22], but the object of study is typically the learned predictor rather than the optimization pipeline. The energy-domain XAI survey of Machlev et al. [23] finds applications concentrated in forecasting and security assessment, not in optimization. For metaheuristics specifically, explainability has been identified as an open research direction rather than an available toolbox [24].

Provenance research supplies the recording formalism — taxonomies of why, how, and where provenance [25] and the W3C PROV recommendation for standardized derivation records [26]. The algorithmic-audit literature argues that accountability requires artifacts generated during the process, not reconstructed after it [27]. TRACE-MOEA operationalizes these principles inside an MOEA: the decision trace archive is a how-provenance record of the search, produced live during execution, and deliberately quarantined from the evaluation objective so that it cannot become a self-serving metric.

### 2.4. Differentiation from the Companion Study

BiLo-NSGA [28] uses the same public candidate generator but a different mechanism. It modifies variation through insertion, substitution, and dependency-aware local moves under a hard budget. TRACE-MOEA acts at selection and archiving through preference elitism, repair, and a trace archive. It also adds a compliance-and-evidence objective and uses review-preference scenarios. Both papers apply separately frozen NERC and MTEP16 checks to paper-specific selected portfolios. They share source corpora and public backtest records, but not method operators, frozen optimization runs, selected portfolios, or inferential claims.

The study targets the intersection of four requirements: search over more than 100 grid candidates, adaptive preference coverage, explicit budget repair, and an audit archive quarantined from evaluation. It also tests whether selected portfolios align with public project outcomes rather than only with the benchmark objectives. No claim is made that this combination resolves real utility review without expert validation.

---

## 3. Problem Formulation and Public Benchmark

### 3.1. Investment-Effectiveness Review as Constrained Five-Objective Selection

Let there be $n$ candidate projects. Candidate $i$ carries a cost $k_i$, a reliability benefit $r_i$, a renewable-accommodation benefit $g_i$, a compliance score $c_i$ (reflecting alignment with regulatory standards), and an evidence score $e_i$ (quantifying how well the project is supported by documented reliability records). Its aggregate schedule-and-implementation risk and review quality are

$$
\rho_i=0.58\rho_i^{\mathrm{sched}}+0.42\rho_i^{\mathrm{impl}},
$$

and

$$
q_i=0.5c_i+0.5e_i,
$$

respectively. A review decision is a binary vector $x\in\{0,1\}^{n}$, with selected-set cardinality $N(x)=\sum_i x_i$.

The selected-project mean risk and mean quality are

$$
\bar\rho(x)=\frac{\sum_{i=1}^{n}\rho_i x_i}{\max\{1,N(x)\}},
$$

and

$$
\bar q(x)=\frac{\sum_{i=1}^{n}q_i x_i}{\max\{1,N(x)\}}.
$$

The investment-effectiveness review problem is formalized as minimization of

$$
F(x)=\left(\sum_i k_i x_i,-\sum_i r_i x_i,-\sum_i g_i x_i,\bar\rho(x),-\bar q(x)\right),
$$

subject to

$$
\sum_{i=1}^{n}k_i x_i\leq B.
$$

The normalized budget violation used by constraint domination is

$$
v_B(x)=\max\!\left\{0,\frac{\sum_i k_i x_i-B}{B}\right\}.
$$

The minus signs convert maximization objectives to minimization for the hypervolume computation.

The fifth objective — mean quality — distinguishes investment-effectiveness review from a generic knapsack. It rewards portfolios containing well-evidenced, compliance-strong projects, a property that review boards must assess. Two standard notions are used throughout. A portfolio is non-dominated if no other portfolio is at least as good on all five objectives and strictly better on one. Hypervolume is the normalized objective-space volume dominated by a front relative to a fixed reference point and is the sole optimization-performance metric used here.

### 3.2. Candidate Pool from Public Data

Real review dossiers are not published, so the pool is generated by deterministic, released rules from three public sources. Table 1 summarizes the derivation; the full source profile is available at `evidence/source/real_project_review_source_profile.csv`.

RTS-GMLC zone aggregates (load, branch ratings and outage rates, generator capacities and renewable shares) produce three archetypes per zone — transmission reinforcement, reliability automation, and renewable support — with costs and benefits as analytic functions of the aggregates. The sixteen highest-stress SimBench subnets each yield a feeder-reinforcement, a storage-flexibility, and a protection-automation candidate driven by subnet load, line statistics, and the distributed-resource gap. The metadata of 40 cached public NERC reliability documents (28 event reports) then adjusts attributes at the archetype level: event-report counts raise reliability values uniformly, inverter-based-resource and storage mentions raise the renewable attribute for the two renewable-facing archetypes, and document counts feed the evidence score. The result is 120 candidates in six archetypes with zone- and feeder-level dependency-group structure.

**Table 1.** Candidate pool derivation (source: `evidence/source/real_project_review_source_profile.csv`).

| Public Source | Used Artifact | Candidates | Archetypes |
|---|---|---|---|
| RTS-GMLC | Zone aggregates of bus, branch, and generator source data | 72 | Transmission reinforcement; reliability automation; renewable support |
| SimBench | Complete mixed network, 16 highest-stress subnets | 48 | Feeder reinforcement; storage flexibility; protection automation |
| NERC / C2GES cache | Metadata of 40 public reliability documents | Attribute adjustment | — |
| **Total** | | **120** | 6 archetypes |

The epistemic status of this pool must be stated explicitly: it is an engineering-plausible, fully reproducible proxy whose every attribute traces to public data through published rules. It contains no expert-labeled review outcomes, and its cost coefficients are synthetic units calibrated to grid-case branch and generation statistics rather than to actual utility expenditure records (see Section 8).

### 3.3. Review Scenarios

Seven experiments vary the candidate pool composition and the assumed stakeholder weighting while the evaluation protocol — objectives, hypervolume bounds, and reference point — never changes (Table 2). The nominal budget is B = 1160 cost units across all scenarios except the budget-stability scenario, where it is tightened to 0.88 x B.

**Table 2.** The seven review scenarios (source: `real_project_review_config.json`, lines 7–15). Stakeholder weights parameterize scalarizing baselines and seed one preference vector of TRACE-MOEA; they never enter the evaluation metric.

| Experiment ID | Pool | Budget | Weight Emphasis |
|---|---|---|---|
| benchmark_portfolio_optimization | Full (120) | 1.00 x B | Balanced |
| distribution_project_review | SimBench candidates only | 1.00 x B | Balanced |
| reliability_driven_review | Reliability-related archetypes | 1.00 x B | Reliability +0.22 |
| renewable_accommodation_review | Renewable/storage archetypes | 1.00 x B | Renewable +0.24 |
| budget_ranking_stability | Full | 0.88 x B | Balanced |
| preference_aware_support | Full | 1.00 x B | Compliance +0.16 |
| traceability_evaluation | Full | 1.00 x B | Evidence +0.28, compliance +0.12 |

### 3.4. Shared-Pipeline Declaration

The candidate-generation code of Section 3.2 is a single versioned artifact used by this paper and by the companion BiLo-NSGA study [28]. Everything above the pool — the five-objective formulation (the companion uses four objectives), the scenario definitions, the method implementations, the statistical protocol, and the external backtests — is specific to this paper. The Data Availability statement records the pipeline location and version.

---

## 4. TRACE-MOEA

Figure 1 separates optimization state from audit state. Preference-guided responses and deterministic budget repair operate around a constrained NSGA-II kernel, while their review-specific events are copied through one-way links to an append-only trace archive. The archive has no return edge: no trace count, coverage statistic, or event attribute enters an objective, constraint, fitness, or selection rule.

![Figure 1. TRACE-MOEA optimization and quarantined audit architecture.](figures/fig_architecture.png)

**Figure 1.** TRACE-MOEA architecture and quarantine invariant. Dashed one-way arrows write preference-elite and repair-drop events to the trace archive. The external checks assess returned portfolios but do not train or tune the optimizer.

The algorithm augments a reproducible constrained non-dominated sorting kernel with three switchable components: the preference-adaptive ranking layer, the budget repair operator, and the decision trace archive. Every design choice below is exercised by a dedicated ablation in Section 6.2 (evidence: `real_project_review_significance.csv`).

**Formal definitions.** A portfolio is \(x\in\{0,1\}^{n}\), with minimized five-objective vector and budget violation

$$
F(x)=[f_1(x),\ldots,f_5(x)]^\top,\qquad
v_B(x)=\max\!\left(0,\sum_{j=1}^{n}c_jx_j-B\right).
$$

Constraint dominance is

$$
x\prec_c y\iff
[v_B(x)=0<v_B(y)]\lor
[v_B(x)=v_B(y)=0\land x\prec_Py]\lor
[v_B(x),v_B(y)>0\land v_B(x)<v_B(y)].
$$

For preference vector \(w_k\) on the simplex, the response score on combined pool \(R_t\) is

$$
\psi_k(x)=\sum_{q=1}^{5}w_{kq}\tilde f_q(x)+\lambda v_B(x),\qquad
x_k^\star=\operatorname*{arg\,min}_{x\in R_t}\psi_k(x).
$$

Every fifth generation, candidate weights are perturbed and projected back to the simplex,

$$
\tilde w_k=\Pi_{\Delta^4}(w_k+\varepsilon_k),\qquad
\varepsilon_k\sim\mathcal N(0,0.1^2I).
$$

The retained \(K\) weights maximize spread of their best responses by greedy max-min dispersion,

$$
w^{+}=\operatorname*{arg\,max}_{w\in\mathcal W\setminus\mathcal W_{\mathrm{keep}}}
\min_{u\in\mathcal W_{\mathrm{keep}}}
\left\|\tilde F(x_w^\star)-\tilde F(x_u^\star)\right\|_2 .
$$

Budget repair ranks selected project \(j\) by

$$
r_j=\frac{b_{j,\mathrm{rel}}+b_{j,\mathrm{ren}}+
b_{j,\mathrm{comp}}+b_{j,\mathrm{evid}}}{c_j},
\qquad
j^-=\operatorname*{arg\,min}_{j:x_j=1}r_j,
$$

and repeats \(x_{j^-}\leftarrow0\) until \(v_B(x)=0\). If \(A_t\) is the trace state and \(e_t\) a repair-drop or preference-elite event, quarantine is the one-way transition

$$
A_{t+1}=A_t\mathbin{\|}e_t,\qquad
F(x),\,v_B(x),\,\psi_k(x),\,\operatorname{Select}(R_t)
\ \perp\ A_{t+1}.
$$

The independence symbol states an implementation invariant: archive contents are absent from every optimization input, not a probabilistic claim. Standard hypervolume is

$$
HV(\mathcal P;r)=\lambda_5\!\left(
\bigcup_{x\in\mathcal P}\prod_{q=1}^{5}[\tilde f_q(x),r_q]\right),
$$

with method-independent bounds and reference point fixed before comparisons.

### 4.1. Constrained Non-Dominated Sorting Kernel

Portfolios are binary vectors evolved by uniform crossover (crossover probability 0.9) and bit-flip mutation at rate 1/n, with constraint-dominated non-dominated sorting (feasible solutions dominate infeasible ones; infeasible solutions are ordered by the magnitude of budget violation) and crowding-distance truncation. The population size is 40 and the generation limit is 40. Initialization uses a low-density strategy (3–15% selection probability per candidate) so that early portfolios begin near the fundable region. The kernel is intentionally unremarkable: the paper's claims rest on the three review-specific components described below, not on exotic selection machinery.

### 4.2. Preference-Adaptive Ranking Layer

The layer maintains K = 8 objective-weight vectors w_1, ..., w_K on the five-dimensional simplex. One vector is initialized from the scenario's stakeholder weighting (Table 2); the remaining seven are sampled from a symmetric Dirichlet(1) distribution. The layer acts twice per generation cycle:

- **Preference elitism.** For each weight vector w_k, the union of parents and offspring is scored by the weighted sum of min-max-normalized objectives plus a violation penalty for infeasible portfolios. The best-response portfolio (the one with lowest scalarized score) is injected into the next population if it was dropped during non-dominated sorting and crowding-distance truncation. Each injection is logged as an archive event carrying the weight-vector index and the portfolio's project identifiers.

- **Adaptive re-selection.** Every five generations, the current vector set is perturbed with independent Gaussian noise (sigma = 0.1, followed by renormalization to the simplex). The best responses of all K original and K perturbed vectors are computed on the current generation's combined parent-offspring pool, and the K vectors whose responses are maximally spread in the normalized objective space (determined by greedy max-min dispersion selection) survive into the next five-generation window.

The layer is designed for review settings in which a decision maker cannot specify exact reference points in advance, an assumption common in preference-guided EMO (Section 2.2). It identifies weighting directions that yield distinct feasible portfolios and preserves representatives from those directions. Whether this mechanism improves hypervolume is evaluated separately; Section 6.2 shows that its isolated pooled effect is small.

### 4.3. Budget Repair

Any initial or offspring portfolio that exceeds the budget is repaired by iteratively dropping the selected project with the lowest equal-weight benefit-to-cost ratio (summed reliability, renewable, compliance, and evidence benefits divided by cost) until the portfolio becomes affordable. Each drop event is recorded in the archive with the generation number and the project identifier. The repair operator is deterministic: given the same portfolio, the drop sequence is identical across seeds.

The purpose of explicit repair is to keep the population inside the fundable region where the review question is actually posed, rather than leaving constraint pressure to selection alone. The ablation `Ablation-NoFeasibilityRepair` disables this operator and relies entirely on constraint-dominated sorting for budget feasibility.

### 4.4. Decision Trace Archive

The archive is an append-only log of two event types: `repair_drop` (from Section 4.3) and `preference_elite` (from Section 4.2). Each event carries the generation number, the affected project identifiers, and for preference-elite events the responsible weight-vector index. Three properties define the archive's role:

- **Completeness for the mechanisms that alter portfolios outside standard variation.** Every repair drop and every preference injection is recorded. Standard crossover and mutation operations are not logged because they are the domain-general search operators; the archive captures the review-specific interventions.
- **Quarantine.** No archive statistic — not count, not coverage, not entropy — appears in any objective function, constraint inequality, or selection criterion. The archive is purely descriptive, reported separately in Section 6.3.
- **Descriptive reporting.** Across all 210 proposed-method runs (7 scenarios x 30 seeds), the archive averages 1126 events per run, and 98.6% of the projects present in the final feasible non-dominated front appear in at least one recorded event (evidence: `real_project_review_leaderboard.csv`, row 2, trace columns). This means that for nearly any project that a reviewer sees recommended, the archive can answer when it was protected by which preference direction and which competing projects were dropped during budget repair.

### 4.5. Algorithm Outline

The complete algorithm is summarized as:

```
TRACE-MOEA(pool, budget, seed):
  initialize 40 low-density binary portfolios
  repair each to budget (log each repair_drop event)            // Section 4.3
  preferences = 1 scenario-seeded + 7 Dirichlet(1) weight vectors  // Section 4.2
  for generation = 1 to 40:
    offspring = uniform crossover + bit-flip mutation (rate 1/n)
    repair offspring portfolios to budget (log repair_drop)     // Section 4.1, 4.3
    survivors = constraint-dominated NDS + crowding truncation
                over (parents union offspring)                  // Section 4.1
    for each weight vector w in preferences:
      inject w's best-response portfolio into survivors         // Section 4.2
      log preference_elite event with w index and project IDs
    end for
    every 5 generations:
      perturb preferences (Gaussian, sigma = 0.1, renormalize)
      keep K vectors with max-min dispersion of best responses  // Section 4.2
  return feasible non-dominated front + decision archive         // Section 4.4
```

---

## 5. Experimental Setup

### 5.1. Methods

Table 3 lists the sixteen methods: the proposed algorithm, seven baselines covering evolutionary, preference-based, and MCDM families relevant to grid review, and eight ablations designed to isolate individual components and objective-visibility effects.

Evolutionary baselines (NSGA-II, R-NSGA-II, and MOEA/D) are pymoo reference implementations on the identical constrained binary problem, with population 40, 40 generations, and the same low-density initialization used by TRACE-MOEA. R-NSGA-II uses the normalized scenario preference point and the same objective bounds as the evaluation protocol; its preference distance never enters TRACE-MOEA's hypervolume. pymoo's MOEA/D has no native constraint-handling mechanism, so it receives a documented penalty formulation. Scalarizing baselines consume the scenario stakeholder weights of Table 2. No baseline receives a pool restriction or cardinality cap.

**Table 3.** Method matrix (source: `real_project_review_config.json`, lines 33–49).

| Method | Role | One-line Description |
|---|---|---|
| TRACE-MOEA | Proposed | Constrained kernel + preference-adaptive layer + budget repair + trace archive |
| NSGA-II | Baseline | pymoo, constrained, binary encoding |
| R-NSGA-II | Baseline | reference-point NSGA-II using the declared scenario preference point |
| MOEA/D | Baseline | pymoo, Tchebycheff decomposition, budget violation as penalty |
| AHP-TOPSIS | Baseline | Consistent AHP matrix, TOPSIS closeness ranking, greedy budget fill |
| Weighted Sum | Baseline | Weighted-score ranking, greedy budget fill |
| Greedy BCR | Baseline | Benefit-cost ratio greedy fill under budget |
| Random Feasible | Baseline | Random-permutation greedy fill |
| Ablation-NoFeasibilityRepair | Ablation | Repair disabled; constraint domination only |
| Ablation-NoPreferenceRanking | Ablation | Preference-adaptive layer disabled |
| Ablation-NoReliabilityFeatures | Ablation | Reliability objective hidden from search (evaluation unchanged) |
| Ablation-NoRenewableFeatures | Ablation | Renewable objective hidden from search |
| Ablation-NoScheduleRisk | Ablation | Risk objective hidden from search |
| Ablation-SingleObjective | Ablation | Search on scalarized weighted sum |
| Ablation-NSGA2Only | Ablation | Bare kernel: no repair, no preference layer, no trace |
| Ablation-SmallProjectPool | Ablation | Candidate pool reduced to one third (~40 candidates) |

Three ablations (NoReliabilityFeatures, NoRenewableFeatures, NoScheduleRisk) hide one objective from the search while the evaluation remains the full five-objective hypervolume; they measure how critical each review dimension is for the optimizer. Three ablations remove algorithmic components (NoFeasibilityRepair, NoPreferenceRanking, NSGA2Only), and two stress the problem structure (SingleObjective, SmallProjectPool).

### 5.2. Protocol, Metric, and Statistics

The archive contains 16 methods x 7 scenarios x 30 invocations, or 3360 rows. Twelve opponents are stochastic: four baselines (NSGA-II, R-NSGA-II, MOEA/D, and Random Feasible) and eight ablations. AHP-TOPSIS, Weighted Sum, and Greedy BCR are deterministic rules. Their 30 identical invocations are retained for a rectangular provenance table but provide an effective sample size of one per scenario. The candidate pool, budget, and scenario weights are fixed within each scenario.

The metric is the standard hypervolume of the feasible non-dominated front. Objective values are normalized by fixed per-scenario bounds computed once from a seeded, method-independent reference set consisting of the empty portfolio, all singleton portfolios, and 2048 random feasible portfolios. The reference point is 1.1 in each normalized dimension. An experiment that returns no feasible portfolio scores zero. The three deterministic ranking rules produce one portfolio per scenario and appear as single markers in Figure 2. Random Feasible is stochastic and is analyzed by seed.

Seed-level inference uses two-sided Mann--Whitney U tests comparing TRACE-MOEA with each of the twelve stochastic opponents per scenario ($n=30$ per group). P-values are Holm-corrected within that stochastic family, with significance at $\alpha=0.05$. We report rank-biserial effect sizes and 5000-resample bootstrap confidence intervals for mean differences. Comparisons with the three deterministic rules are descriptive point gaps and are not assigned inferential p-values. The corrected table is available at `evidence/tables/real_project_review_inference_v2.csv`; the original rectangular significance table is retained only as computational provenance.

To remove implementation ambiguity, objective $j$ is normalized with method-independent bounds $(l_j,u_j)$ as

$$
\tilde f_j(x)=\min\!\left\{1,\max\!\left[0,\frac{f_j(x)-l_j}{u_j-l_j}\right]\right\}.
$$

For a feasible non-dominated front $\mathcal{P}$ and reference point $z^{\mathrm{ref}}=(1.1,\ldots,1.1)$, the reported quality score is

$$
HV(\mathcal{P})=\lambda_5\!\left(\bigcup_{x\in\mathcal{P}}[\tilde F(x),z^{\mathrm{ref}}]\right).
$$

For two seed samples with ranks $R_i$, the first-sample statistic is

$$
U_1=n_1n_2+\frac{n_1(n_1+1)}{2}-\sum_{i=1}^{n_1}R_i,
$$

and ordered raw p-values are adjusted monotonically by

$$
p^{\mathrm{Holm}}_{(i)}=\max_{k\leq i}\min\!\left\{1,(M-k+1)p_{(k)}\right\}.
$$

An earlier internal revision of this benchmark scored methods with a composite index that consumed method-owned parameters, creating a circular evaluation. That revision was invalidated and its artifacts are preserved under a `deprecated_circular` suffix in the evidence trail. Every number reported in this paper comes from the re-implemented v2 protocol described above, in which the evaluation depends on candidate attributes only.

---

## 6. Results

### 6.1. Main Comparison

Table 4 reports the pooled leaderboard across all seven scenarios. TRACE-MOEA leads the table with mean hypervolume 0.17425 (standard deviation 0.00635), +0.89% over NSGA-II (0.17270) and +29.4% over AHP-TOPSIS (0.13468). Across four stochastic baselines and seven scenarios, TRACE-MOEA has 27 positive mean differences in 28 comparisons; 24 are Holm-significant wins and none is a significant loss. All 21 descriptive gaps against the three deterministic ranking rules favor TRACE-MOEA. R-NSGA-II provides the direct preference-based control and is retained despite its lower pooled hypervolume.

**Table 4.** Pooled leaderboard over seven scenarios. Stochastic methods have 210 runs; deterministic-rule rows summarize seven unique outputs retained as 210 repeated provenance rows. Trace and decision-coverage columns are descriptive only.

| Method | Role | Mean HV | Std HV | Mean Runtime (s) | Trace Events/Run | Decision Coverage |
|---|---|---|---|---|---|---|
| **TRACE-MOEA** | **Proposed** | **0.17425** | **0.00635** | **0.113** | **1126** | **0.986** |
| Ablation-NoScheduleRisk | Ablation | 0.17403 | 0.00702 | 0.107 | 1125 | 0.986 |
| Ablation-NoPreferenceRanking | Ablation | 0.17396 | 0.00564 | 0.109 | 803 | 0.966 |
| Ablation-NoFeasibilityRepair | Ablation | 0.17300 | 0.00652 | 0.106 | 320 | 0.865 |
| NSGA-II | Baseline | 0.17270 | 0.00642 | 0.146 | — | — |
| Ablation-NSGA2Only | Ablation | 0.17249 | 0.00652 | 0.102 | — | — |
| Ablation-NoRenewableFeatures | Ablation | 0.16930 | 0.00375 | 0.106 | 919 | 0.964 |
| AHP-TOPSIS | Baseline | 0.13468 | 0.00269 | 0.065 | — | — |
| R-NSGA-II | Baseline | 0.11980 | 0.02671 | 0.192 | — | — |
| Ablation-SingleObjective | Ablation | 0.11617 | 0.02637 | 0.112 | 1611 | 0.984 |
| Ablation-NoReliabilityFeatures | Ablation | 0.09081 | 0.02124 | 0.106 | 915 | 0.977 |
| Random Feasible | Baseline | 0.08064 | 0.02261 | 0.065 | — | — |
| Ablation-SmallProjectPool | Ablation | 0.06920 | 0.01280 | 0.079 | 654 | 0.970 |
| Greedy BCR | Baseline | 0.05576 | 0.03248 | 0.065 | — | — |
| Weighted Sum | Baseline | 0.04105 | 0.01991 | 0.065 | — | — |
| MOEA/D | Baseline | 0.01954 | 0.01379 | 0.375 | — | — |

The four non-significant baseline comparisons all involve NSGA-II: benchmark_portfolio_optimization (Holm p = 0.064), budget_ranking_stability (p = 0.053), distribution_project_review (p = 1.0, with a nominally negative difference of -0.13%), and reliability_driven_review (p = 0.242). Every comparison with R-NSGA-II is significant. Figure 2 shows the original distribution view; the direct preference control is isolated in Figure 5 so that its lower scale does not compress the close TRACE-MOEA--NSGA-II differences.

![Figure 2](figures/fig_hv_boxplot.png)

**Figure 2.** Hypervolume across the seven review scenarios (30 seeds per box for stochastic methods). AHP-TOPSIS, Weighted Sum, and Greedy BCR produce one portfolio per scenario and appear as diamonds. Random Feasible is stochastic. TRACE-MOEA and NSGA-II contend at the top of every scenario; the remaining baselines operate in a different performance regime.

Table 5 breaks down the TRACE-MOEA vs. NSGA-II comparison by scenario. The three Holm-significant wins occur exactly in the scenarios whose stakeholder weighting departs most from uniform (preference_aware_support, renewable_accommodation_review, traceability_evaluation). In the balanced full-pool scenarios (benchmark, budget stability) the margins remain positive (+1.1–1.3%) but do not survive Holm correction at n = 30, and on the SimBench-only pool (distribution) the two methods are statistically identical.

**Table 5.** TRACE-MOEA versus NSGA-II per scenario (30 seeds). Confidence intervals are pointwise, multiplicity-unadjusted 5000-resample bootstrap intervals for the mean difference; $r_{rb}$ is the rank-biserial effect. Holm-adjusted rank-test p-values determine significance across twelve stochastic opponents within each scenario (`real_project_review_inference_v2.csv`).

| Scenario | TRACE-MOEA | NSGA-II | Mean difference (95% CI) | $r_{rb}$ | Holm p |
|---|---:|---:|---:|---:|---:|
| benchmark_portfolio_optimization | 0.17441 | 0.17224 | 0.00218 [0.00047, 0.00425] | 0.376 | 0.0637 |
| budget_ranking_stability (0.88 x B) | 0.17139 | 0.16955 | 0.00184 [0.00026, 0.00353] | 0.358 | 0.0529 |
| distribution_project_review | 0.16490 | 0.16512 | -0.00022 [-0.00115, 0.00066] | -0.020 | 1.000 |
| preference_aware_support | 0.17512 | 0.17229 | 0.00283 [0.00138, 0.00477] | 0.593 | 0.000407 |
| reliability_driven_review | 0.17223 | 0.17144 | 0.00080 [0.00010, 0.00153] | 0.298 | 0.242 |
| renewable_accommodation_review | 0.18646 | 0.18505 | 0.00141 [0.00051, 0.00229] | 0.504 | 0.00325 |
| traceability_evaluation | 0.17521 | 0.17325 | 0.00196 [0.00102, 0.00292] | 0.560 | 0.00100 |

The pattern is consistent with, but does not prove, the design hypothesis. Gains appear in scenarios with explicit preference emphasis; in balanced scenarios, differences are smaller and do not separate statistically.

### 6.2. Ablations: Where the Gain Does and Does Not Come From

![Figure 3](figures/fig_ablation.png)

**Figure 3.** Pooled mean hypervolume of the full method and the eight ablations (error bars = one standard deviation). Two annotations identify the results that most constrain architectural interpretation.

Figure 3 orders the attribution. The dominant effects are related to objective visibility: hiding the reliability objective from search costs 47.9% of the pooled hypervolume (0.09081 vs. 0.17425); scalarizing all objectives into a single weighted sum costs 33.3% (0.11617); hiding the renewable objective costs 2.8% (0.16930); and cutting the candidate pool to one third costs 60.3% (0.06920). The five-dimensional review structure itself — not any single algorithmic trick — carries most of the task difficulty.

Among the component-level ablations, disabling budget repair (NoFeasibilityRepair) costs 0.72% of pooled hypervolume and drops the decision archive coverage from 0.986 to 0.865, confirming that repair events are a material part of the trace record (evidence: `real_project_review_leaderboard.csv`, rows 2 vs. 5). Disabling all review-specific components at once (NSGA2Only, the bare kernel) costs 1.01% (0.17249 vs. 0.17425).

The component results constrain the algorithmic claim. Removing preference adaptation (NoPreferenceRanking) changes pooled hypervolume by only 0.17%. The full method wins the renewable scenario under the within-scenario family ($p_{Holm}=0.0206$), but no preference-ablation contrast remains significant after a second Holm correction across the seven scenarios ($p=0.0722$ for that cell). Removing schedule risk changes pooled hypervolume by 0.13%. The risk-blind variant is higher in traceability_evaluation ($p_{Holm}=0.0219$ within scenario), but that contrast also falls just outside the cross-scenario threshold ($p=0.0510$). These are exploratory mechanism patterns rather than resolved component effects.

Two readings follow. The schedule-risk objective enters as a portfolio mean, producing a weak search gradient and, in one scenario, an adverse difference. Preference-injected portfolios also overlap substantially with those already preserved by constraint-dominated crowding, consistent with evidence that preference guidance is not automatically beneficial [20]. The complete TRACE-MOEA has the highest pooled hypervolume among the tested external baselines and no significant per-scenario loss, but its margin over its leanest viable variant is small. A hypervolume-only user could disable preference adaptation with little measured loss. The trade-off is reduced trace coverage (0.966 versus 0.986) and removal of records identifying which weighting directions shaped the returned front.

### 6.3. Traceability: Descriptive Results

Because no trace statistic enters any ranking, the archive is reported descriptively. Across the 210 proposed-method runs, the archive averages 1126 events per run (standard deviation 210 events), and 98.6% of the projects appearing in the returned feasible non-dominated front are covered by at least one event that names them (evidence: `real_project_review_leaderboard.csv`, row 2, trace columns).

The two trace-bearing ablations bracket the sources. Without the preference-adaptive layer (NoPreferenceRanking), the archive records only repair-drop events and achieves a mean coverage of 96.6%. Without the repair operator (NoFeasibilityRepair), the archive records only preference-elite events and achieves coverage of 86.5%. The complete method's 98.6% coverage thus arises from the combination of the two mechanisms, each filling coverage gaps left by the other.

We do not claim that the archive improves review outcomes or that 98.6% coverage is the correct target. Validating whether the archive helps review boards make faster or more consistent decisions would require a human-subjects study that has not been performed (Section 8). The descriptive claim is limited to a near-complete, per-project record of review-specific interventions. Archive variables are quarantined from the evaluation function; this does not imply zero computational or human-review cost.

Figure 4 makes the trace mechanism measurable without turning it into an optimization objective. Removing preference ranking reduces both the number of recorded events and project coverage moderately. Removing repair sharply reduces both quantities because repair-drop events disappear. The bare kernel has neither trace channel. These are diagnostic differences in audit-state production; they are not evidence that a larger archive improves portfolio quality or human review.

![Figure 4. Decision-trace diagnostics for the full method and trace-bearing ablations.](figures/fig_trace_diagnostics.png)

**Figure 4.** Decision-trace diagnostics pooled across seven scenarios and 30 seeds (210 runs per configuration). (a) Fraction of projects in the final feasible front covered by at least one recorded event; (b) number of logged events per run. Boxes are descriptive. Trace statistics are quarantined from all objectives, constraints, and selection decisions.

### 6.4. Budget Sensitivity

The direct-control scan freezes the 120-candidate pool and balanced preference point, varies the budget multiplier over $\{0.75,1.00,1.25\}$, and runs TRACE-MOEA, R-NSGA-II, and NSGA-II for 30 independent seeds at each level. It therefore adds 270 runs without reusing the heterogeneous scenario rows of the main experiment. Alongside hypervolume, it reports the Euclidean distance from the normalized compromise vector to the declared preference point,

$$
d_{\mathrm{pref}}(x)=\left\|\tilde F(x)-z^{\mathrm{pref}}\right\|_2,
$$

where lower values indicate closer preference achievement. This second metric prevents a preference method from being judged only by global front coverage.

**Table 6.** Budget and direct preference-control scan (30 seeds per cell; lower preference distance is better).

| Budget | Method | Mean HV | Mean preference distance | HV verdict versus TRACE |
|---|---|---:|---:|---|
| 0.75 x B | TRACE-MOEA | 0.16650 | 0.52985 | -- |
| 0.75 x B | NSGA-II | 0.16439 | 0.53252 | TRACE win, Holm $p=0.0327$ |
| 0.75 x B | R-NSGA-II | 0.11007 | 0.55375 | TRACE win, Holm $p<10^{-9}$ |
| 1.00 x B | TRACE-MOEA | 0.17509 | 0.52597 | -- |
| 1.00 x B | NSGA-II | 0.17304 | 0.53007 | TRACE win, Holm $p=0.00177$ |
| 1.00 x B | R-NSGA-II | 0.12862 | 0.53431 | TRACE win, Holm $p<10^{-9}$ |
| 1.25 x B | TRACE-MOEA | 0.17849 | 0.52323 | -- |
| 1.25 x B | NSGA-II | 0.17675 | 0.52764 | TRACE win, Holm $p=0.00144$ |
| 1.25 x B | R-NSGA-II | 0.13563 | 0.52898 | TRACE win, Holm $p<10^{-9}$ |

Hypervolume rises with budget for all three methods. TRACE-MOEA significantly exceeds both controls at every budget level, and its mean preference distance is also lowest at every level. The inferential tests in Table 6 apply to hypervolume; the distance ordering is descriptive because a second multiplicity family was not preregistered. R-NSGA-II's adverse result is retained as an implementation-specific direct control, not generalized to all reference-point algorithms.

![Figure 5. Preference-aware controls across three budget levels.](figures/fig_preference_budget_controls.png)

**Figure 5.** Hypervolume and preference-achievement distance for TRACE-MOEA, NSGA-II, and R-NSGA-II at 0.75, 1.00, and 1.25 times the nominal budget. Error bars show one standard deviation over 30 seeds. The two panels keep global front coverage and distance to the declared preference point conceptually separate.

### 6.5. External Consistency: A Two-Rung Descriptive Ladder

Hypervolume measures optimization quality on the proxy objectives; it does not establish that selected portfolios identify real grid risk or predict project outcomes. We therefore add two external-consistency checks. Both are descriptive because the NERC rule overlaps the construction corpus and the MTEP project-level tests do not preserve portfolio dependence or a confirmatory comparison family.

![Figure 6](figures/fig_external_validity.png)

**Figure 6.** External-consistency ladder. (a) NERC rule backtest: priority-capture ratio against a rule combining NERC-topic archetype weights with NERC-independent physical stress percentiles (10 seeded compromise portfolios per method). (b) MISO MTEP16 outcome backtest: broad outcome-capture ratio against real built/withdrawn/unresolved project statuses. The vertical line marks parity with uniform random selection.

**Rung 1 — NERC rule consistency.** Each candidate receives a priority score equal to a NERC-report-topic weight for its archetype multiplied by a stress percentile from raw RTS-GMLC and SimBench statistics. The score is computed before the pool's NERC-based attribute adjustment, preventing a direct mirror of that adjustment. Alignment is the mean priority of selected projects divided by the mean priority of the full pool; values above 1.0 indicate oversampling of documented-risk candidates.

TRACE-MOEA achieves priority capture of 1.55 in the benchmark scenario and 1.34 in the reliability-driven scenario (evidence: `real_nerc_rule_backtest.csv`). Its Kendall tau values are 0.01 and 0.15. AHP-TOPSIS posts the highest alignment (capture 2.29 and 1.63; tau 0.45 and 0.52). These are raw, unadjusted associations in a descriptive check. AHP-TOPSIS directly weights reliability-type attributes adjacent to the rule, so its high alignment partly reflects construct overlap. Greedy BCR provides an adverse descriptive control, with capture 0.23--0.53 and negative raw tau values.

**Rung 2 — MISO MTEP16 outcomes.** The second rung replaces a constructed rule with observable real-world outcomes. From the MTEP16 Appendix A and B project table (1218 projects), those with positive 2016 cost estimates form backtest pools of 1097 and 1062 projects for the two audited scenarios. Features use only 2016-vintage fields (cost estimate, project type, voltage, mileage, appendix status, record date). Labels come from quarterly status snapshots (2016-12 through 2018-01) and the 2026 MISO in-service and active-project lists, yielding 924 built, 19 explicitly withdrawn, 39 deferred, and 236 unresolved projects across the full table. No outcome field enters any feature, and no constant was fitted to outcomes.

TRACE-MOEA's broad capture is 1.079 in the benchmark scenario and 1.070 in the reliability-driven scenario. Raw project-level diagnostics are point-biserial $r=0.169$ ($p<10^{-7}$) and $r=0.151$ ($p=10^{-6}$), respectively; the corresponding unadjusted Mann--Whitney readouts point in the same direction (evidence: `real_mtep_backtest.csv`). These p-values are descriptive diagnostics, not confirmatory tests: projects co-occur within selected portfolios, and no portfolio-preserving permutation family was preregistered. The capture ratios exceed those of the tested evolutionary baselines, but AHP-TOPSIS reaches 1.100 in the benchmark scenario and Weighted Sum reaches 1.132 in the reliability-driven scenario. Strict-label results use only 19 explicit withdrawals and are underpowered.

Five boundary conditions restrict the interpretation of Rung 2. First, the MTEP16 approved pool is approximately 98% built within the strictly labeled subset, so the backtest measures alignment within an already board-approved plan. Second, the `unresolved` class may contain projects re-scoped under new identifiers. Third, the pool contains almost no renewable or storage projects, so this rung provides no evidence for renewable-related objectives. Fourth, appendix status is decision-time information correlated with broad outcomes. Fifth, the raw project-level association tests do not preserve dependence induced by portfolio selection. Within these limits, the backtest shows descriptive contact with real outcomes; it does not establish above-chance portfolio performance, best alignment, or engineering-economic effectiveness.

### 6.6. Search-Effort and Outcome-Sensitivity Diagnostics

Figure 7 links the optimization score to the algorithmic work recorded in the frozen archive. TRACE-MOEA averages 0.17425 hypervolume, 0.1130 s, 806 accepted preference-guided moves, 1126 trace events, and 0.986 project coverage per run. Removing preference ranking leaves 0.17396 hypervolume while reducing the archive to about 803 events; disabling repair removes accepted repair moves and lowers coverage to 0.865. NSGA-II attains 0.17270 at 0.1456 s without a project-level decision trace. These comparisons establish the cost of audit production but do not treat event count as an optimization objective.

![Figure 7. Search effort, archive coverage, and hypervolume from the frozen TRACE-MOEA records.](figures/fig_search_audit_efficiency.png)

**Figure 7.** Pooled search-and-audit profile over seven scenarios and 30 seeds per method. Hypervolume, runtime, accepted moves, trace events, and coverage retain their native units; the panels should not be read as a scalar composite score.

The diagnostic clarifies the practical trade-off. TRACE-MOEA is faster than the tested NSGA-II implementation at this small problem size, but deterministic baselines remain orders of magnitude cheaper. The method's additional product is the trace archive: 98.6% coverage means that almost every project represented in the returned fronts has at least one recorded decision event. Coverage is a software-level completeness measure, not evidence that human reviewers find the explanations sufficient.

Figure 8 re-expresses the MTEP16 result without collapsing broad and strict labels. Broad capture is 1.079 and 1.070 in the benchmark and reliability-driven scenarios, respectively, whereas strict capture is 1.014 and 1.000. The broad view supplies statistical power by treating unresolved projects as non-built; the strict view avoids that uncertain label but contains only 19 withdrawals in the full inventory. Their divergence is not a robustness success: it quantifies the outcome-definition sensitivity that bounds the external-validity claim.

![Figure 8. Broad and strict MTEP16 outcome capture for the proposed method and baselines.](figures/fig_mtep_outcome_backtest.png)

**Figure 8.** MTEP16 outcome-capture ratios for the two audited scenarios. The dashed line denotes parity with uniform selection. Broad labels include unresolved projects among negatives; strict labels compare built projects only with explicit withdrawals. Proposed-method highlighting is visual identification and does not override the reported significance tests.

The two diagnostics close different audit questions. Figure 7 shows what computation and trace volume were required to obtain the proxy-objective result; Figure 8 shows how much the real-outcome result depends on an uncertain negative class. Neither adds a new experiment or changes the frozen protocol. Both are generated directly from the archived CSV files, and their aggregate tables are retained under `manuscript/derived_tables/` for independent recomputation.

---

## 7. Discussion

**What the evidence suggests about mechanism.** The three significant comparisons with NSGA-II occur in preference-emphasized scenarios (Table 5), but this between-method pattern does not identify the responsible component. The direct NoPreferenceRanking ablation is not significant after correction across its seven scenarios. Preference-injected portfolios appear to overlap those already preserved by crowding, and the observed scenario pattern remains a hypothesis for a future targeted design. The traceability scenario also favors the risk-blind variant within its scenario family, but this result falls just outside the second cross-scenario correction. Neither pattern supports a causal component claim.

**What the external-consistency ladder adds.** The two checks expose two limitations that a proxy-only study would miss. AHP-TOPSIS is favored on the NERC view by construct overlap. The MTEP view measures capture within an already-approved plan and is bounded by its high build rate. These diagnostics narrow the external claim rather than validate the review method.

**Relation to the companion study.** BiLo-NSGA [28] asks how variation-stage, project-vocabulary local moves behave under hard budgets. TRACE-MOEA studies selection-stage preference adaptation and an audit archive. The problem formulations differ in dimensionality (five objectives versus four), operators, scenarios, and frozen optimization records. Both papers use separately executed NERC and MTEP16 consistency checks on their own selected portfolios. Sharing the candidate generator and public source records makes provenance comparable; it does not make the algorithmic evidence interchangeable.

**Operational reading for planning departments.** Against the strongest general-purpose optimizer, NSGA-II, the pooled hypervolume gain is below 1%. The practical differentiator is therefore the decision trace archive, which supplies per-project records unavailable from the baselines in Table 3.

The direct R-NSGA-II comparison changes what can be claimed about preference guidance. TRACE-MOEA performs better on this benchmark in both front coverage and mean preference distance, including across the three frozen budgets, but the result is not evidence that adaptive weights are universally better than reference points. R-NSGA-II uses one declared point and one matched configuration; different points, normalization, or niching parameters could change its behavior. The defensible advance is that a direct preference-family control now exists and the proposed method survives it under the disclosed setup.

Against AHP-TOPSIS, the portfolio-level hypervolume gain is 29.4%, and both backtests show that the optimized portfolios do not lose all alignment with documented risk. This comparison remains a proxy-objective result, not proof of superior utility decisions. Mean runtime is 0.113 s per run, so seed ensembles and budget what-if analyses are inexpensive at the tested scale. Deterministic repair also ensures that each returned portfolio satisfies the benchmark budget.

---

## 8. Limitations

Seven limitations constrain the scope of the claims in this paper.

1. **Proxy task without expert ground truth.** All main-benchmark claims address algorithmic performance on a reproducible public proxy whose objectives are engineering proxies. No expert-labeled review outcomes exist. An annotated subset with inter-rater agreement and rank correlation against the proxy objectives remains undone. The NERC and MTEP checks assess descriptive alignment but do not validate review correctness.

2. **External consistency is assessed descriptively only.** Neither rung establishes external validity because portfolio-preserving confirmatory inference and expert ground truth are absent. AHP-TOPSIS and Weighted Sum also attain the highest capture on individual views. The MTEP check operates within an already-approved plan, with an approximately 98% strict-label build rate and only 19 explicit negatives.

3. **Uncalibrated economics.** Candidate costs are synthetic units derived from network aggregates (branch ratings, generator capacities, line lengths); benefits are engineering proxies derived from the same aggregates. No engineering-economic conclusion — in currencies, rates of return, tariffs, or cost-effectiveness thresholds — can be drawn from this paper, and none is offered.

4. **Traceability is measured, not validated.** The decision archive's coverage (98.6%) shows that the record is nearly complete, and its quarantine prevents trace statistics from entering objectives, selection, or the reported metric. Whether the archive actually improves board decisions, review speed, stakeholder contestability, or regulatory compliance requires a human-subjects study that has not been performed.

5. **Single benchmark family with no electrical verification.** All seven scenarios instantiate one 120-candidate pool derived from one combination of public sources. Portfolio feasibility is budgetary (the repair operator enforces the cost constraint) but not electrical: no candidate portfolio has been checked for AC power-flow feasibility using the cached SimBench or RTS-GMLC network models. A second, independently constructed pool and an OPF-based feasibility check of recommended portfolios are natural extensions.

6. **Preference-layer hyperparameters remain fixed.** The adaptive layer was tested with $K=8$ weight vectors and one update cadence (every five generations). The three-level budget scan tests constraint tightness and includes a direct preference-based control, but it does not vary $K$, update cadence, objective weights, or pool size. The design has been evaluated at the tested budgets; the direct optimization benefit of the preference layer remains unresolved.

7. **One direct preference-based comparator is not a family survey.** R-NSGA-II closes the absence of a reference-point control and is evaluated under the same population, generations, constraints, and three budget levels. However, the study does not include RVEA, NSGA-III with preference articulation, or interactive decision-maker feedback. The result supports TRACE-MOEA against the implemented R-NSGA-II configuration, not superiority over the broader preference-based EMO family.

A final remark concerns the released evidence trail rather than the method. The evidence package deliberately retains deprecated pipeline revisions — files suffixed `_deprecated_circular` (the v1 protocol invalidated for circular metric construction, Section 5.2) and the intermediate weak/near-miss v1–v3 series — alongside the current outputs. They are kept for transparency: they document how the evaluation protocol was audited and corrected, which we consider part of the reproducibility record. Readers should treat these files as historical artifacts only. No number reported in this paper derives from any deprecated revision, and the deprecation suffixes mark files that must not be used for method comparison.

---

## 9. Conclusions

TRACE-MOEA combines a preference-adaptive weight-vector population, deterministic budget repair, and a quarantined decision trace archive. The archive records review-specific interventions without entering the evaluation, while repair maintains budget feasibility throughout search.

On the five-objective, 120-project proxy benchmark, TRACE-MOEA attains pooled mean hypervolume 0.17425, 0.89% above NSGA-II (0.17270). Across four stochastic baselines and seven scenarios, it has 27 positive mean differences in 28 comparisons, 24 Holm-significant wins, and no significant loss. Twenty-one deterministic-rule gaps are descriptive and all favor TRACE-MOEA. In the separate 270-run scan, TRACE-MOEA significantly exceeds R-NSGA-II and NSGA-II at all three budgets while retaining the lowest descriptive preference distance. The archive covers 98.6% of recommended projects and remains quarantined from the metric.

The NERC consistency backtest yields priority-capture ratios of 1.34–1.55. The MISO MTEP16 backtest yields broad capture of 1.070–1.079 and a raw point-biserial correlation up to 0.169. Because the public-record tests do not preserve portfolio dependence or a comparison family, these values support descriptive external consistency rather than confirmatory above-chance alignment.

The preference-adaptive layer changes pooled hypervolume by 0.17%, but its direct effect is unresolved after cross-scenario correction. Its demonstrated function is the preference-elite portion of the audit record. The schedule-risk contrast is also unresolved after the second correction, and the external record is descriptive. Expert-labeled utility data and a human evaluation of the archive remain necessary before claiming review effectiveness.

---

## Author Contributions

[AUTHOR INPUT REQUIRED: assign the CRediT roles to Yubin Lin, Jiyu Li, Xiaofei Ruan, Xiaoyu Huang, and Dishan Yang, and obtain approval from every author.] All authors have read and agreed to the published version of the manuscript.

## Funding

[AUTHOR INPUT REQUIRED: insert the verified funder, grant number, and APC funder, or state "This research received no external funding."]

## Institutional Review Board Statement

Not applicable.

## Informed Consent Statement

Not applicable.

## Data Availability Statement

All data sources used in this study are publicly accessible. RTS-GMLC source data is available at https://github.com/GridMod/RTS-GMLC. The SimBench complete mixed dataset is available at https://simbench.de. NERC reliability reports are available at https://www.nerc.com; only report metadata is used in this study, and a manifest with official URLs and SHA-256 checksums is released in place of redistributed PDF files. MISO MTEP16 Appendix A and B project records, subsequent quarterly status snapshots, and the 2026 MISO in-service and active-project portal lists are available at https://www.misoenergy.org.

The candidate-derivation pipeline, complete TRACE-MOEA implementation, baseline and ablation configurations, 3360 main per-run records, the 270-run three-budget direct-control scan, corrected inference tables, backtest analyses, and figure scripts are included in the supplementary review package and are available from the corresponding author. The earlier 450-run 0.75x scan is retained as superseded sensitivity provenance and is not substituted for the frozen three-budget comparison. A persistent public archive can be supplied before publication, subject to third-party redistribution terms. The companion BiLo-NSGA study [28] shares the versioned candidate generator, NERC source corpus, and public MTEP16 records. Algorithm implementations, problem objectives, scenario definitions, run archives, selected portfolios, and reported comparisons are paper-specific. The deprecated v1 evaluation remains marked `_deprecated_circular` and is excluded from every result. The evidence tree is indexed by `evidence/README.md`.

## Acknowledgments

During the preparation of this manuscript, the authors used generative AI tools (Claude, Anthropic) for language refinement, literature summary, and formatting assistance, under the authors' full intellectual oversight. The authors have reviewed and edited all AI-assisted content and take full responsibility for the final manuscript.

## Conflicts of Interest

The authors declare no conflicts of interest.

---

## References

<!-- MDPI numbered reference style. DOI metadata re-audited against Crossref on 2026-08-09. -->

1. Hemmati, R.; Hooshmand, R.-A.; Khodabakhshian, A. State-of-the-art of transmission expansion planning: Comprehensive review. *Renewable and Sustainable Energy Reviews* **2013**, *23*, 312–319. https://doi.org/10.1016/j.rser.2013.03.015

2. Lumbreras, S.; Ramos, A. The new challenges to transmission expansion planning. Survey of recent practice and literature review. *Electric Power Systems Research* **2016**, *134*, 19–29. https://doi.org/10.1016/j.epsr.2015.10.013

3. Wang, J.-J.; Jing, Y.-Y.; Zhang, C.-F.; Zhao, J.-H. Review on multi-criteria decision analysis aid in sustainable energy decision-making. *Renewable and Sustainable Energy Reviews* **2009**, *13*(9), 2263–2278. https://doi.org/10.1016/j.rser.2009.06.021

4. Kumar, A.; Sah, B.; Singh, A.R.; Deng, Y.; He, X.; Kumar, P.; Bansal, R.C. A review of multi criteria decision making (MCDM) towards sustainable renewable energy development. *Renewable and Sustainable Energy Reviews* **2017**, *69*, 596–609. https://doi.org/10.1016/j.rser.2016.11.191

5. Rodkumnerd, P.; Pothinun, T.; Phumpho, S.; Watson, N.; Siritaratiwat, A.; Srirattanawichaikul, W.; Khunkitti, S. Fuzzy Analytical Hierarchy Process-Based Multi-Criteria Decision Framework for Risk-Informed Maintenance Prioritization of Distribution Transformers. *Energies* **2026**, *19*(2), 460. https://doi.org/10.3390/en19020460

6. Liesio, J.; Mild, P.; Salo, A. Preference programming for robust portfolio modeling and project selection. *European Journal of Operational Research* **2007**, *181*(3), 1488–1505. https://doi.org/10.1016/j.ejor.2005.12.041

7. Mild, P.; Liesio, J.; Salo, A. Selecting infrastructure maintenance projects with Robust Portfolio Modeling. *Decision Support Systems* **2015**, *77*, 21–30. https://doi.org/10.1016/j.dss.2015.05.001

8. Deb, K.; Pratap, A.; Agarwal, S.; Meyarivan, T. A fast and elitist multiobjective genetic algorithm: NSGA-II. *IEEE Transactions on Evolutionary Computation* **2002**, *6*(2), 182–197. https://doi.org/10.1109/4235.996017

9. Zhang, Q.; Li, H. MOEA/D: A Multiobjective Evolutionary Algorithm Based on Decomposition. *IEEE Transactions on Evolutionary Computation* **2007**, *11*(6), 712–731. https://doi.org/10.1109/TEVC.2007.892759

10. Munoz, F.D.; Hobbs, B.F.; Ho, J.L.; Kasina, S. An Engineering-Economic Approach to Transmission Planning Under Market and Regulatory Uncertainties: WECC Case Study. *IEEE Transactions on Power Systems* **2014**, *29*(1), 307–317. https://doi.org/10.1109/TPWRS.2013.2279654

11. Gao, C.; Wang, X.; Li, D.; Han, C.; You, W.; Zhao, Y. A Novel Hybrid Power-Grid Investment Optimization Model with Collaborative Consideration of Risk and Benefit. *Energies* **2023**, *16*(20), 7215. https://doi.org/10.3390/en16207215

12. Deb, K.; Jain, H. An Evolutionary Many-Objective Optimization Algorithm Using Reference-Point-Based Nondominated Sorting Approach, Part I: Solving Problems With Box Constraints. *IEEE Transactions on Evolutionary Computation* **2014**, *18*(4), 577–601. https://doi.org/10.1109/TEVC.2013.2281535

13. Deb, K.; Sundar, J. Reference point based multi-objective optimization using evolutionary algorithms. In *Proceedings of the 8th Annual Conference on Genetic and Evolutionary Computation (GECCO '06)*, Seattle, WA, USA, 8–12 July 2006; pp. 635–642. https://doi.org/10.1145/1143997.1144112

14. Thiele, L.; Miettinen, K.; Korhonen, P.J.; Molina, J. A Preference-Based Evolutionary Algorithm for Multi-Objective Optimization. *Evolutionary Computation* **2009**, *17*(3), 411–436. https://doi.org/10.1162/evco.2009.17.3.411

15. Ben Said, L.; Bechikh, S.; Ghedira, K. The r-Dominance: A New Dominance Relation for Interactive Evolutionary Multicriteria Decision Making. *IEEE Transactions on Evolutionary Computation* **2010**, *14*(5), 801–818. https://doi.org/10.1109/TEVC.2010.2041060

16. Bechikh, S.; Kessentini, M.; Ben Said, L.; Ghedira, K. Preference Incorporation in Evolutionary Multiobjective Optimization: A Survey of the State-of-the-Art. *Advances in Computers* **2015**, *98*, 141–207. https://doi.org/10.1016/bs.adcom.2015.03.001

17. Wang, H.; Olhofer, M.; Jin, Y. A mini-review on preference modeling and articulation in multi-objective optimization: current status and challenges. *Complex & Intelligent Systems* **2017**, *3*(4), 233–245. https://doi.org/10.1007/s40747-017-0053-9

18. Cheng, R.; Jin, Y.; Olhofer, M.; Sendhoff, B. A Reference Vector Guided Evolutionary Algorithm for Many-Objective Optimization. *IEEE Transactions on Evolutionary Computation* **2016**, *20*(5), 773–791. https://doi.org/10.1109/TEVC.2016.2519378

19. Li, K.; Deb, K.; Yao, X. R-Metric: Evaluating the Performance of Preference-Based Evolutionary Multiobjective Optimization Using Reference Points. *IEEE Transactions on Evolutionary Computation* **2018**, *22*(6), 821–835. https://doi.org/10.1109/TEVC.2017.2737781

20. Li, K.; Liao, M.; Deb, K.; Min, G.; Yao, X. Does Preference Always Help? A Holistic Study on Preference-Based Evolutionary Multiobjective Optimization Using Reference Points. *IEEE Transactions on Evolutionary Computation* **2020**, *24*(6), 1078–1096. https://doi.org/10.1109/TEVC.2020.2987559

21. Barredo Arrieta, A.; Diaz-Rodriguez, N.; Del Ser, J.; Bennetot, A.; Tabik, S.; Barbado, A.; Garcia, S.; Gil-Lopez, S.; Molina, D.; Benjamins, R.; Chatila, R.; Herrera, F. Explainable Artificial Intelligence (XAI): Concepts, taxonomies, opportunities and challenges toward responsible AI. *Information Fusion* **2020**, *58*, 82–115. https://doi.org/10.1016/j.inffus.2019.12.012

22. Miller, T. Explanation in artificial intelligence: Insights from the social sciences. *Artificial Intelligence* **2019**, *267*, 1–38. https://doi.org/10.1016/j.artint.2018.07.007

23. Machlev, R.; Heistrene, L.; Perl, M.; Levy, K.Y.; Belikov, J.; Mannor, S.; Levron, Y. Explainable Artificial Intelligence (XAI) techniques for energy and power systems: Review, challenges and opportunities. *Energy and AI* **2022**, *9*, 100169. https://doi.org/10.1016/j.egyai.2022.100169

24. Bacardit, J.; Brownlee, A.E.I.; Cagnoni, S.; Iacca, G.; McCall, J.; Walker, D. The intersection of evolutionary computation and explainable AI. In *Proceedings of the Genetic and Evolutionary Computation Conference Companion (GECCO '22 Companion)*, Boston, MA, USA, 9–13 July 2022; pp. 1757–1762. https://doi.org/10.1145/3520304.3533974

25. Herschel, M.; Diestelkamper, R.; Ben Lahmar, H. A survey on provenance: What for? What form? What from? *The VLDB Journal* **2017**, *26*(6), 881–906. https://doi.org/10.1007/s00778-017-0486-1

26. Moreau, L.; Groth, P.; Cheney, J.; Lebo, T.; Miles, S. The rationale of PROV. *Journal of Web Semantics* **2015**, *35*, 235–257. https://doi.org/10.1016/j.websem.2015.04.001

27. Raji, I.D.; Smart, A.; White, R.N.; Mitchell, M.; Gebru, T.; Hutchinson, B.; Smith-Loud, J.; Theron, D.; Barnes, P. Closing the AI accountability gap: defining an end-to-end framework for internal algorithmic auditing. In *Proceedings of the 2020 Conference on Fairness, Accountability, and Transparency (FAT* '20)*, Barcelona, Spain, 27–30 January 2020; pp. 33–44. https://doi.org/10.1145/3351095.3372873

28. Lin, Y.; Zhang, J.; Huang, X.; Yang, D.; Li, J. BiLo-NSGA: Bidirectional Local Search Within Non-Dominated Sorting for Budget-Constrained Power Grid Project Portfolio Review. Unpublished manuscript, 2026; available to editors and reviewers on request.

29. Liang, Y.; Liu, H.; Zhou, H.; Meng, Z.; Liu, J.; Zhou, M. Multi-Stage Coordinated Planning for Transmission and Energy Storage Considering Large-Scale Renewable Energy Integration. *Applied Sciences* **2024**, *14*(15), 6486. https://doi.org/10.3390/app14156486

30. Bhattarai, S.; Karki, R. Interruption Cost Estimation for Value-Based Reliability Investment in Emerging Smart Grid Resources. *Applied Sciences* **2024**, *14*(19), 8651. https://doi.org/10.3390/app14198651

31. Zhang, T.; Wu, J.; Hong, J.; Zhou, H.; Zheng, J.; Zheng, Z.; Niu, C.; Gao, Z.; Peng, L.; Lin, Z. Optimal Planning and Investment Return Analysis of Grid-Side Energy Storage System Addressing Multi-Dimensional Grid Security Requirements. *Applied Sciences* **2025**, *15*(22), 11944. https://doi.org/10.3390/app152211944

32. Xiong, H.; Feng, B.; Yan, F.; Kang, Y.; Hu, Y.; Li, Q.; Tan, Q. A Hybrid Heuristic--Benders Method for Wind--Hydrogen Investment Planning with Non-Analytical Cost Functions. *Energies* **2026**, *19*(9), 2172. https://doi.org/10.3390/en19092172

33. Mizrak, F.; Yasar, O. A Secondary-Data-Driven Decision Support Framework for Strategic Energy Investment Prioritization: An Explainable Multi-Criteria Application Across Countries. *Energies* **2026**, *19*(14), 3243. https://doi.org/10.3390/en19143243
