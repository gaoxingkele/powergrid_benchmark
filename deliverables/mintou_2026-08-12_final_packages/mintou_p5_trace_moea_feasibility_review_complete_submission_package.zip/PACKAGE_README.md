# mintou_p5_trace_moea_feasibility_review: final internal submission package

Built on 2026-08-12 from the current official manuscript and frozen evidence tree.

Contents:

- `manuscript_project/`: current Markdown manuscript, figures, tables, and journal-formatted LaTeX/PDF source tree. Transient LaTeX build files are excluded.
- `reproducibility/`: code, configurations, evidence tables, run archives, provenance, and claim-scope records for this paper.
- `portfolio_audit/`: the three rounds of logic, statistics, and theory/innovation reviews, the 10-paper journal comparison, and reference-verification summary.
- `shared_reproducibility/`: the corrected statistical audit implementation and its regression tests.
- `SHA256SUMS.txt`: SHA-256 hashes for every included payload file.

Scientific status: the three expert-review dimensions passed after all blocker/major corrections. Core experiments did not require a new run.

Submission gate: do not upload until all `[AUTHOR INPUT REQUIRED]` fields, CRediT roles, author approvals, affiliations, correspondence, ORCIDs where requested, funding/APC statements, and journal declarations have been completed by the authors. Scientific review PASS is not an acceptance guarantee.
