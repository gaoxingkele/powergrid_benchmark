"""Single-objective optimization algorithms."""
