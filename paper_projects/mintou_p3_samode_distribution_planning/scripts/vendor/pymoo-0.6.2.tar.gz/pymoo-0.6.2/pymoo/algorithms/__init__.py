"""Optimization algorithms."""
