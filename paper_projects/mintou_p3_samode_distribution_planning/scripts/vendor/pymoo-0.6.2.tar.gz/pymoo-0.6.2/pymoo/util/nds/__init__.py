"""Non-dominated sorting utilities."""
