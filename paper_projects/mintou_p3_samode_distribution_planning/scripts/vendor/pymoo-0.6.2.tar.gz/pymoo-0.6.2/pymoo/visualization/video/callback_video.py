"""Animation callback for visualization."""

from pymoo.visualization.matplotlib import plt

from pymoo.core.callback import Callback
from pymoo.visualization.scatter import Scatter


class AnimationCallback(Callback):
    """Base class for animation callbacks."""

    def __init__(  # noqa: ANN201
        self,
        do_show: bool = False,
        do_close: bool = True,
        nth_gen: int = 1,
        dpi=None,  # noqa: ANN001
        recorder=None,  # noqa: ANN001
        fname=None,  # noqa: ANN001
        exception_if_not_applicable: bool = True,
    ) -> None:
        super().__init__()
        self.nth_gen = nth_gen
        self.do_show = do_show
        self.do_close = do_close
        self.exception_if_not_applicable = exception_if_not_applicable

        self.recorder = recorder
        if self.recorder is None and fname is not None:
            try:
                from pyrecorder.recorder import Recorder
                from pyrecorder.writers.video import Video
                from pyrecorder.converters.matplotlib import Matplotlib

                self.recorder = Recorder(Video(fname), converter=Matplotlib(dpi=dpi))
            except Exception as e:
                raise Exception(
                    "Please install or update pyrecorder for animation support: pip install -U pyrecorder"
                ) from e

    def update(self, algorithm):  # noqa: ANN001, ANN201
        if algorithm.n_gen == 1 or algorithm.n_gen % self.nth_gen == 0:
            try:
                figure = self.do(algorithm.problem, algorithm)

                if self.do_show:
                    if figure is not None:
                        figure.show()
                    else:
                        plt.show()

                if self.recorder is not None:
                    self.recorder.record(fig=figure)

                if self.do_close:
                    plt.close(fig=figure)

                return figure

            except Exception as ex:
                if self.exception_if_not_applicable:
                    raise ex

    def do(self, problem, algorithm, **kwargs):  # noqa: ANN001, ANN201
        pass


class ObjectiveSpaceAnimation(AnimationCallback):
    """Animation callback for objective space visualization."""

    def __init__(self, recorder=None, **kwargs) -> None:  # noqa: ANN001
        if recorder is None:
            from pyrecorder.recorder import Recorder
            from pyrecorder.writers.streamer import Streamer

            recorder = Recorder(Streamer())
        super().__init__(recorder=recorder, **kwargs)

    def update(self, algorithm):  # noqa: ANN001, ANN201
        F = algorithm.opt.get("F")
        pf = algorithm.problem.pareto_front()

        sc = Scatter()
        sc.add(F)
        if pf is not None:
            sc.add(pf, plot_type="line", color="black", alpha=0.7)
        sc.do()

        self.recorder.record()
