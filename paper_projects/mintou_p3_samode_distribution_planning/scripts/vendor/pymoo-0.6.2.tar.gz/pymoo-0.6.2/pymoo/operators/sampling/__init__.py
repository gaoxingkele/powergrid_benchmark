"""Sampling operators."""
