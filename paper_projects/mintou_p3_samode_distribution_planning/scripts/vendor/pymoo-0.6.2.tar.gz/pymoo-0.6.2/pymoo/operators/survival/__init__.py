"""Survival operators."""
