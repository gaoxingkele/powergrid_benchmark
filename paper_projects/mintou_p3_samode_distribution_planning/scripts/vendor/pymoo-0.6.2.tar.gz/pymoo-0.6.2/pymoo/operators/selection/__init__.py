"""Selection operators."""
