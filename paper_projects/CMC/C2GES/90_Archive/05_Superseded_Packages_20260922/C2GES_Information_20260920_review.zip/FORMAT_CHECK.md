# MDPI Information format check — C2GES 2026-09-20

Official style: MDPI layout (about-200-word single-paragraph abstract, 3–10 keywords), IMRaD, numbered references, Data Availability, CRediT, funding, COI, ethics. LaTeX class `Definitions/mdpi` **v6.5a dated 11 September 2026**. Journal option `information`.

| Item | Status |
|---|---|
| `\documentclass[information,article,submit,moreauthors]` | Pass |
| Title / authors / corresponding email `yangyong1@sgepri.sgcc.com.cn` | Pass |
| Featured Application | Removed |
| Abstract one paragraph, 175 words (≤ ~200) | Pass |
| Keywords 6 (3–10) | Pass |
| Evidence-layer table (`tab:evidence-layers`) | Pass: four layers with may/may-not-support bounds |
| Path-component primary evidence | Normalized Full vs no-path; 7-series −0.00799/−0.00718 |
| Historical numbers conserved | Full 0.1060/0.1276; unrenorm 0.1094/0.1310 |
| Related Work | GraphLSS/StrucSum difference clauses; STAS/Bi-GAE positioning; no ECT-BPS; no 15-test STAS/PacSum scores |
| Priority C dispositions | Expert 20–30, STAS/PacSum-on-15, 12-position window, RST/EDU, BERTScore/NLI deferred or declined |
| PDF 30 pages, 0 Overfull, 0 undefined citations/references | Pass |
| Supplementary PDF 5 pages | Pass |
| Word `paper_information.docx` | 12 embedded images, 14 tables |

Cover letter section: Information Applications (or Artificial Intelligence).

## SuSy upload

1. Manuscript ZIP: `C2GES_Information_20260920_submission.zip`
2. PDF: `01_Manuscript/PDF/C2GES_Information_2026-09-20_diagnostic_submission.pdf`
3. Supplementary ZIP: `C2GES_Information_20260920_supplementary.zip`
4. Cover letter: paste `INFORMATION_COVER_LETTER.md` into the portal.
5. Word is author-review only.

Hashes after packaging are recorded in `PACKAGE_VERIFICATION.json` / `PACKAGE_VERIFICATION_submission.json`.
