# MDPI Information format check — C2GES 2026-09-24

Official style: MDPI layout (about-200-word single-paragraph abstract, 3–10 keywords), IMRaD, numbered references, Data Availability, CRediT, funding, COI, ethics. LaTeX class `Definitions/mdpi` **v6.5a dated 11 September 2026**. Journal option `information`.

| Item | Status |
|---|---|
| `\documentclass[information,article,submit,moreauthors]` | Pass |
| Title / authors / corresponding email `yangyong1@sgepri.sgcc.com.cn` | Pass |
| Featured Application | Removed |
| Abstract one paragraph, 190 words (≤ 200) | Pass |
| Keywords 6 (3–10) | Pass |
| Evidence-layer table (`tab:evidence-layers`) | Pass: four layers with may/may-not-support bounds |
| Path-component primary evidence | Normalized Full vs no-path; 7-series −0.00799/−0.00718 |
| Historical numbers conserved | Full 0.1060/0.1276; unrenorm 0.1094/0.1310 |
| Related Work | GraphLSS/StrucSum difference clauses; STAS/Bi-GAE positioning; four same-journal *Information* comparators added (`verma2023graph`, `koniaris2023legal`, `azhar2025urdu`, `nechakhin2024orkg`); no ECT-BPS; no 15-test STAS/PacSum scores |
| Priority C dispositions | Expert 20–30, STAS/PacSum-on-15, 12-position window, RST/EDU, BERTScore/NLI deferred or declined |
| PDF 32 pages, 6 figures, 15 tables, 44 references, 0 Overfull, 0 undefined citations/references | Pass |
| External prospective evaluation (new §4.11 + Supplementary Table S10) | Pass: 19 frozen external reports from ENTSO-E and NERC; Full−no-path −0.002906 at 260 words (Holm 0.046875, negative on 7 of 7 discordant documents) and TextRank−no-path +0.022940 (Holm 0.032380); the 110-word contrasts are not significant |
| Annotated-study gate (`tab:e2-gate`) | Pass: three preconditions plus the list of claims that stay closed until E2 |
| Adjacent-corpus construct audit (new §4.10 + Supplementary Table S9) | Pass: GUM 7,678 EDUs / 4.55% role coverage / 45 of 7,285 pairs with role evidence / 0 admissible edges; EBM-NLP 2,139 sentences, precision 0.610 and 0.807 against base rates 0.524 and 0.519, recall 0.064 and 0.060 |
| Public verification | `02_Revision_and_QA/04_Build_Reports/C2GES_DIAGNOSTIC_PUBLIC_VERIFICATION.json`: **PASS** on route `diagnostic`, Python 3.12.10, covering the RSI held-out layer, synthetic stress v8, the construct-audit aggregates, and the external prospective record (documents, families, four contrasts, reference floor, and the absence of third-party corpus text inside the release scopes) |
| Supplementary PDF 5 pages | Pass |
| Word `paper_information.docx` | 12 embedded images, 15 tables |

Cover letter section: Information Applications (or Artificial Intelligence).

## SuSy upload

1. Manuscript ZIP: `C2GES_Information_20260922_submission.zip`
2. PDF: `01_Manuscript/PDF/C2GES_Information_2026-09-22_diagnostic_submission.pdf`
3. Supplementary ZIP: `C2GES_Information_20260922_supplementary.zip`
4. Cover letter: paste `INFORMATION_COVER_LETTER.md` into the portal.
5. Word is author-review only.

Hashes after packaging are recorded in `PACKAGE_VERIFICATION.json` / `PACKAGE_VERIFICATION_submission.json`.
