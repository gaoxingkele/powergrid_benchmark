# MDPI Information format check — C2GES 2026-09-16

Official style: MDPI layout (about-200-word single-paragraph abstract, 3–10 keywords), IMRaD, numbered references, Data Availability, CRediT, funding, COI, ethics. LaTeX class `Definitions/mdpi` dated 23 June 2026. Journal option `information`.

| Item | Status |
|---|---|
| `\documentclass[information,article,submit,moreauthors]` | Pass |
| Title / authors Bijing Liu, Yong Yang / corresponding email `yangyong1@sgepri.sgcc.com.cn` | Pass (unchanged from the diagnostic ApplSci author record) |
| Featured Application | Removed (ApplSci-only; `mdpi.cls` would otherwise reprint it) |
| Abstract one paragraph, 200 words | Pass |
| Keywords 6 (3–10) | Pass |
| Sections: Introduction, Related Work, Materials and Methods, Results, Discussion, Conclusions | Pass (Related Work is extra, allowed; Limitations is §5.5) |
| CRediT, funding 521300250006, IRB N/A, consent N/A, data availability, acknowledgments (Codex/DeepSeek), COI | Pass |
| Methods §3.12 names Codex and DeepSeek; Acknowledgments matches | Pass |
| PDF 27 pages, MDPI Information running header, numbered refs 1–38 | Pass |
| Word author-review conversion `paper_information.docx` | Generated from the same tex; SuSy should still take the LaTeX ZIP + PDF |
| Diagnostic bounds retained: no system superiority / structural-proxy validity / operational benefit; seven-series is post-access exploratory; machine labels are not human/expert | Pass in abstract, Discussion, Conclusions, cover letter |

No Overfull boxes; table Underfull warnings only. Cover letter section: Information Applications (or Artificial Intelligence).
