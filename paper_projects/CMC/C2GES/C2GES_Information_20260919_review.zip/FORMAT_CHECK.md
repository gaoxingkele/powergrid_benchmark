# MDPI Information format check — C2GES 2026-09-19

Official style: MDPI layout (about-200-word single-paragraph abstract, 3–10 keywords), IMRaD, numbered references, Data Availability, CRediT, funding, COI, ethics. LaTeX class `Definitions/mdpi` **v6.5a dated 11 September 2026** (official ACS citation-style ZIP). Journal option `information`.

| Item | Status |
|---|---|
| `\documentclass[information,article,submit,moreauthors]` | Pass (matches official template; `pdftex` is not required in v6.5a) |
| Title / authors Bijing Liu, Yong Yang / corresponding email `yangyong1@sgepri.sgcc.com.cn` | Pass |
| Affiliations | Pass: institution, city, postal code, country; province omitted per MDPI layout 2.3 |
| Featured Application | Removed (ApplSci-only; `mdpi.cls` would otherwise reprint it) |
| Abstract one paragraph, 195 words (≤ ~200); no citations, figures, or display math | Pass |
| Abstract abbreviations | NERC, ROUGE-L, Semantic-MMR, Holm–Bonferroni expanded on first use |
| Keywords 6 (3–10), semicolon-separated | Pass |
| Sections: Introduction, Related Work, Materials and Methods, Results, Discussion, Conclusions | Pass (Related Work extra, allowed; Limitations is §5.5) |
| Figures 1–6: vector PDF, caption below, `\centering`, cited before appearance | Pass |
| Tables: caption above, `booktabs` | Pass |
| Display equations numbered (1)–(6) with `\label`/`\eqref` | Pass |
| CRediT, funding 521300250006, IRB N/A, consent N/A, data availability, acknowledgments (Codex/DeepSeek), COI, abbreviations | Pass |
| Methods names Codex and DeepSeek; Acknowledgments matches | Pass |
| PDF 29 pages, MDPI Information running header, 0 Overfull, 0 undefined citations/references | Pass |
| Supplementary PDF 5 pages (Tables S1–S8, Figure S4) | Pass |
| Word author-review conversion `paper_information.docx` | 12 embedded 300 dpi images (6 figures + 6 equations), 13 tables; SuSy should still take the LaTeX ZIP + PDF |
| Diagnostic bounds retained | Pass in abstract, Discussion, Conclusions, cover letter |

No Overfull boxes; table Underfull warnings only. Cover letter section: Information Applications (or Artificial Intelligence).

## SuSy upload

1. Manuscript ZIP: `C2GES_Information_20260919_submission.zip` — tex, pdf, bib, `Definitions/`, `figures/` only.
2. Compiled PDF (also inside the ZIP): `01_Manuscript/PDF/C2GES_Information_2026-09-19_diagnostic_submission.pdf`
3. Supplementary ZIP: `C2GES_Information_20260919_supplementary.zip`
4. Cover letter: paste `INFORMATION_COVER_LETTER.md` into the portal; do not put it in the manuscript ZIP.
5. Word file is for author reading, not a substitute for the LaTeX ZIP.

## Package hashes (2026-09-19, after the round-3 revision and the Word rebuild)

- submission ZIP SHA-256: `2822dbd050d2278ae6638c4a88880b5b07feae63677733b5107ebb860d2c0b3e` (20 files)
- review ZIP SHA-256: see `PACKAGE_VERIFICATION.json` — this file ships inside that ZIP, so a hash written here would invalidate itself on every rebuild
- supplementary ZIP SHA-256: `ee3f36897510e28786a695805a151d8e05e144617c0dbd29a00dbcf184d9c930` (3 files)
- tex SHA-256: `f761bd110ffafca79382194af496689a3d6f6eae65f9ddc6c12037a787587898`
- pdf SHA-256: `57501a0e606c9328c24b854c17075dac1c28c9fde1179109b504cc61f873ebb9` (29 pages)
- supplementary PDF SHA-256: `5356aeeadc2c4fd2e7f752deeb6ec1545a74a586a84f7f5a93141700b5e3538b` (5 pages)
- release manifest SHA-256: `5d74357d63ee4ab6616c45188ebc8580770415aca8c628d5ebb40c03999e778f` (534 files, PASS)
