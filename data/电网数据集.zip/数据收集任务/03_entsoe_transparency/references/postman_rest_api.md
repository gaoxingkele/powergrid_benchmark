# ENTSO-E Postman REST API Reference

## 文档入口

```text
https://documenter.getpostman.com/view/7009892/2s93JtP3F6
```

页面标题：

```text
Transparency Platform Restful API
```

页面说明显示该 Postman collection 用于提供 ENTSO-E Transparency Platform RESTful API 的开发者友好技术文档，并指向 Web API knowledgebase。

## 是否可用

可以作为 ENTSO-E API 参数和请求示例参考使用。它和当前 README 中记录的调用方式一致：

- API endpoint：`https://web-api.tp.entsoe.eu/api`
- 认证参数：`securityToken=$ENTSOE_SECURITY_TOKEN`
- 返回格式：XML

## 本地验证记录

2026-07-16 使用本地 `.envrc` 中的 `ENTSOE_SECURITY_TOKEN` 执行小范围 smoke test：

```text
HTTP=200
response root: GL_MarketDocument
TimeSeries=1
Period=1
Point=96
period_start=2024-01-01T00:00Z
period_end=2024-01-02T00:00Z
resolution=PT15M
first_quantity=39744.85
last_quantity=37970.87
```

响应临时保存到 `/tmp/entsoe_smoke_20240101.xml` 做解析，未写入仓库。真实 token 不写入本文档。

## 使用建议

- 查参数组合时优先看 Postman 文档和 ENTSO-E Web API knowledgebase。
- benchmark 落地前先确定数据类型，例如负荷、电价、发电、跨区交换。
- 每个数据类型先用 1 天或更短时间窗口测试，再扩展到年度数据。
