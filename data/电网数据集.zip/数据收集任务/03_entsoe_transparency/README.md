# `entsoe_transparency`

## 数据源定位

ENTSO-E Transparency Platform 提供欧洲电力系统运行和市场透明度数据，适合负荷预测、电价预测、跨区交换、发电结构、市场运行分析等 benchmark。

官方入口：

```text
https://transparency.entsoe.eu/
```

API endpoint：

```text
https://web-api.tp.entsoe.eu/api
```

## 当前收集状态

- 已注册网页账号。
- 已发送 RESTful API access 申请邮件并拿到 security token。
- 本地 `.envrc` 已配置 `ENTSOE_SECURITY_TOKEN`，真实值不写入文档。
- 2026-07-16 已完成 smoke test：示例请求返回 HTTP 200 和 XML `GL_MarketDocument`，包含 1 条 `TimeSeries` 和 96 个 15 分钟 `Point`。
- 历史归档中未发现已落盘的 ENTSO-E 数据。

## 是否需要账号或 token

- 需要注册 ENTSO-E Transparency Platform 账号。
- 注册后默认不一定显示 API token。
- 需要邮件申请 RESTful API access。
- 开通后在账号页生成 `security token`；当前 token 已可用。

建议环境变量：

```bash
export ENTSOE_SECURITY_TOKEN=""
```

## 已执行申请动作

已向以下邮箱发送申请：

```text
transparency@entsoe.eu
```

邮件主题：

```text
RESTful API access
```

开通后已登录网站，在 `My Account` 中生成或查看 Web API Security Token。

## 参考文档

- Postman 文档：`references/postman_rest_api.md`

## 示例调用方式

可按如下形式请求：

```bash
curl "https://web-api.tp.entsoe.eu/api?securityToken=$ENTSOE_SECURITY_TOKEN&documentType=A65&processType=A16&outBiddingZone_Domain=10Y1001A1001A82H&periodStart=202401010000&periodEnd=202401020000"
```

说明：

- ENTSO-E API 参数比较强依赖数据类型。
- 不同任务需要不同 `documentType`、`processType`、区域 domain code 和时间范围。
- 老师跑 benchmark 前，需要先确定要取负荷、电价、发电还是跨区交换。

## 推荐处理方式

1. 将 `ENTSOE_SECURITY_TOKEN` 真实值通过私密渠道交给老师。
2. 根据 benchmark 任务选定 1-2 个数据类型，补充具体 API 参数模板。
3. 先拉小时间范围做 smoke test，再扩展年份。

## 最终交付给老师

- `ENTSOE_SECURITY_TOKEN` 的真实值，私下发送。
- API endpoint。
- 至少一个已验证可返回数据的 API 请求模板。
- 参数说明：数据类型、区域 code、时间范围。

## 验收标准

- ENTSO-E 回复已开通 RESTful API access，且本地 token 已通过 smoke test。
- 老师设置 `ENTSOE_SECURITY_TOKEN` 后，示例请求返回 XML 数据。
- 文档中不出现真实 token。
