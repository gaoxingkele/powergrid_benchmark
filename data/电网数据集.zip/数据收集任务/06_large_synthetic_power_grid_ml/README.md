# `large_synthetic_power_grid_ml`

## 数据源定位

该项指 Zenodo 上的大规模合成电网 ML 数据，适合用作较大规模电网机器学习 benchmark，例如网络拓扑、发电、负荷、线路状态或潮流相关任务。

当前候选入口：

```text
https://zenodo.org/records/13378476
```

## 当前收集状态

- 历史归档中未发现该 Zenodo 数据已落盘。
- 该类资源通常不需要 API token。
- 需要先确认老师要哪个具体子集，不建议盲目全量下载。

## 是否需要账号或 token

- 不需要 token。
- 通常不需要 Zenodo 账号。
- 直接按 Zenodo record 的 file URL 下载。

## 示例下载方式

先创建目录：

```bash
mkdir -p large_synthetic_power_grid_ml
```

按具体文件下载，例如：

```bash
wget "https://zenodo.org/records/13378476/files/europe_network.json?download=1" \
  -O large_synthetic_power_grid_ml/europe_network.json

wget "https://zenodo.org/records/13378476/files/gens_2016.zip?download=1" \
  -O large_synthetic_power_grid_ml/gens_2016.zip

wget "https://zenodo.org/records/13378476/files/loads_2016.zip?download=1" \
  -O large_synthetic_power_grid_ml/loads_2016.zip
```

如果 benchmark 需要线路潮流或线路状态，再补：

```bash
wget "https://zenodo.org/records/13378476/files/lines_2016.zip?download=1" \
  -O large_synthetic_power_grid_ml/lines_2016.zip
```

## 推荐处理方式

1. 先让老师确认 benchmark 需要的任务类型：
   - 负荷/发电预测
   - 潮流预测
   - 拓扑/线路状态建模
   - 大规模图学习
2. 根据任务选择最小文件组合。
3. 先下载一个年份或一个核心子集。
4. 校验文件大小、解压、字段结构后再扩展。

## 最终交付给老师

- Zenodo record URL。
- 推荐下载的文件列表。
- `wget` 命令。
- 子集选择说明。
- 明确说明：无需 token，但数据可能较大，建议按任务下载。

## 验收标准

- 已确认最终 Zenodo record 是否就是老师图中所指数据源。
- 已列出最小可运行 benchmark 所需文件。
- 下载命令能保存文件，且不需要 API token。
