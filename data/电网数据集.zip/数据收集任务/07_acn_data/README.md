# `acn_data`

## 数据源定位

ACN-Data 是 Caltech EV 充电网络数据，提供充电会话、站点、连接时间、断开时间、需求量等信息，适合 EV charging scheduling、需求响应、充电行为建模和优化 benchmark。

官方入口：

```text
https://ev.caltech.edu/dataset.html
```

## 当前收集状态

- 当前环境已有 `ACN_API_TOKEN`。
- 历史归档中已成功通过 API 拉取 sample。
- 本次 smoke test 也验证 token 可调用，返回 `_items`、`_links`、`_meta`。

历史数据证据：

```text
history_archive/data-and-assets/data/paper3/raw/acn/
```

已落盘内容：

- `caltech_sample/sessions.jsonl`：50 条 session。
- `caltech_sample/fetch_meta.json`
- `caltech_sample/pages.json`
- `caltech_202401/`：曾尝试按 2024-01 条件拉取，但 session 数为 0。

## 是否需要账号或 token

- 需要 ACN API token。
- 当前已经具备 token，不需要重新申请。
- 交付时只写环境变量名，不在文档里写真实 token。

建议环境变量：

```bash
export ACN_API_TOKEN=""
```

## 示例调用方式

```bash
curl -H "Authorization: Bearer $ACN_API_TOKEN" \
  "https://ev.caltech.edu/api/v1/sessions/caltech?max_results=10"
```

如果需要分页，需要根据返回的 `_links` 或 `_meta` 继续请求下一页。

## 推荐处理方式

1. 把 `ACN_API_TOKEN` 私下交给老师。
2. 先用 `max_results=10` 做 smoke test。
3. 正式 benchmark 前不要只用 50 条 sample，应按站点和时间范围拉取足够规模。
4. 如果需要充电功率时序，要确认 API 参数是否包含 timeseries。

## 最终交付给老师

- `ACN_API_TOKEN` 的真实值，私下发送。
- API endpoint 和 curl 示例。
- 历史验证说明：已成功拉取 Caltech sample。
- 说明 sample 规模不足以支撑正式实验，需要扩大拉取。

## 验收标准

- 老师设置 `ACN_API_TOKEN` 后，curl 示例返回 JSON。
- 返回结果包含 `_items`。
- 文档中不出现真实 token。
