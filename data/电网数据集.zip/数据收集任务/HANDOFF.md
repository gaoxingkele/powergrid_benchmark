# Handoff: 7 个电网数据源 token / 下载方式交付

**Generated**: 2026-07-14 14:14:02 CST
**Branch**: main
**Status**: In Progress

## Goal

为老师要求的 7 个电网 benchmark 数据源整理可复现获取方式：已有 API token 的记录环境变量和调用模板，需申请的记录申请状态，不需要 token 的记录下载入口和最终处理方式。交付目录是 `数据收集任务/`。

## Completed

- [x] 创建总览文档：`数据收集任务/README.md`
- [x] 创建 7 个数据源目录及独立 README：
  - `01_tamu_test_cases`
  - `02_eia_opendata`
  - `03_entsoe_transparency`
  - `04_pjm_dataminer`
  - `05_nsrdb`
  - `06_large_synthetic_power_grid_ml`
  - `07_acn_data`
- [x] 盘点历史归档中已有的数据/API 证据：
  - EIA 已有 `EIA_API_KEY`，历史成功拉取多个 RTO/BA 的 2022-2023 小时数据。
  - NREL/NSRDB 已有 `NREL_API_KEY`，历史成功拉取 6 个城市 2022 年 CSV。
  - ACN 已有 `ACN_API_TOKEN`，历史和当前 smoke test 均能调用。
- [x] 确认 ENTSO-E 需要额外邮件开通 RESTful API access；用户已发送邮件。
- [x] 阅读 PJM Data Miner 2 API Guide，确认 Non-member/Other 账号需要邮件申请 Data Miner API access；用户已发送邮件。
- [x] 检查新文档未写入真实 token。

## Not Yet Done

- [ ] 等 ENTSO-E 邮件回复，生成 `ENTSOE_SECURITY_TOKEN` 后私下交给老师，并更新 `03_entsoe_transparency/README.md` 状态。
- [ ] 等 PJM 邮件回复，拿到 Data Miner API subscription key 后私下交给老师，并更新 `04_pjm_dataminer/README.md` 状态。
- [ ] 用浏览器打开 TAMU 下载页，确认老师要哪些 ACTIVSg case，并判断是否能拿到真实文件直链。
- [ ] 确认 `large_synthetic_power_grid_ml` 的最终 Zenodo record 和老师需要的子集，避免盲目下载大文件。
- [ ] 可选：补一个 `.env.template` 和 `smoke_test_api.py`，但当前用户只要求 README 和目录文档。

## Failed Approaches (Don't Repeat These)

- Tried treating PJM `www.pjm.com` / PJM Tools profile as the API key入口. This only showed normal tools access (`eDART`, `Markets Gateway`, `Planning Center`, etc.) and no Data Miner API key. Correct path is `https://apiportal.pjm.com/` plus Data Miner API provisioning; for Non-member/Other accounts, PJM API Guide says to email `accountmanager@pjm.com` with the internal-use confirmation.
- Tried assuming ENTSO-E token appears immediately after account registration. It does not. The user must email `transparency@entsoe.eu` with subject `RESTful API access`; after approval, token generation appears under account settings.
- Tried command-line `curl` access to TAMU page; local TLS connection was reset. Treat this as command-line/site compatibility issue, not evidence that approval is required. Use browser first; script only if a stable file URL is visible.
- Tried command-line NREL smoke test during this session; it failed at TLS connection layer (`SSL_ERROR_SYSCALL`) rather than with an API-key error. Historical NSRDB CSVs still prove the API was previously usable.

## Key Decisions

| Decision | Rationale |
|----------|-----------|
| Do not put real API keys in README files | These docs may be committed/shared; tokens should be sent privately. |
| Treat the work as 7 independent tasks | Each data source has different access model: token, email approval, form download, or Zenodo direct download. |
| Count EIA, NSRDB, ACN as already token-ready | Environment variables exist and historical successful calls/data were found. |
| Count ENTSO-E and PJM as pending | User has sent required emails, but access tokens/keys are not received yet. |
| Distinguish EIA-PJM from PJM Data Miner | Historical `PJM_2022_2023` is EIA regional data, not PJM Data Miner API data. |

## Current State

**Working**:
- Documentation handoff directory exists and contains 8 README files.
- `EIA_API_KEY`, `NREL_API_KEY`, `ACN_API_TOKEN` were visible in the shell during this session. Do not print them in future responses.
- EIA smoke test returned `EIA_OK total=96 rows=5 first_period=2024-01-01T23`.
- ACN smoke test returned keys `_items,_links,_meta` and `count=2`.

**Blocked / Pending**:
- ENTSO-E: waiting for RESTful API access approval and token.
- PJM: waiting for Data Miner API access provisioning and subscription key.
- TAMU: needs browser confirmation of case download links.
- Zenodo large synthetic: needs final record/subset confirmation.

**Uncommitted Changes**:
- New untracked directory: `数据收集任务/`
- Existing unrelated untracked file also present: `scripts/autofigure_pdf_regenerate.py` (not touched for this task).
- `git diff --stat` showed no tracked-file diff because these are untracked additions.

## Files to Know

| File | Why It Matters |
|------|----------------|
| `数据收集任务/README.md` | Top-level summary of all 7 data sources and current progress. |
| `数据收集任务/01_tamu_test_cases/README.md` | TAMU ACTIVSg download status and handling plan. |
| `数据收集任务/02_eia_opendata/README.md` | EIA token status and API template. |
| `数据收集任务/03_entsoe_transparency/README.md` | ENTSO-E pending email approval and API template. |
| `数据收集任务/04_pjm_dataminer/README.md` | PJM pending API subscription and API templates. |
| `数据收集任务/05_nsrdb/README.md` | NREL/NSRDB key status and download API template. |
| `数据收集任务/06_large_synthetic_power_grid_ml/README.md` | Zenodo large synthetic download/subset plan. |
| `数据收集任务/07_acn_data/README.md` | ACN token status and API template. |

## Code Context

Environment variables to hand off privately to the teacher:

```bash
export EIA_API_KEY=""
export NREL_API_KEY=""
export ACN_API_TOKEN=""
export ENTSOE_SECURITY_TOKEN=""
export PJM_API_KEY=""
```

Known historical data evidence:

```text
history_archive/data-and-assets/data/paper1/raw/eia/
history_archive/data-and-assets/data/paper1/raw/nsrdb/
history_archive/data-and-assets/data/paper3/raw/acn/
```

PJM API key usage shapes:

```bash
curl "https://api.pjm.com/api/v1/load_frcstd_7_day?rowCount=50000&startRow=1&format=csv&subscription-key=$PJM_API_KEY"

curl "https://api.pjm.com/api/v1/act_sch_interchange/metadata" \
  -H "Ocp-Apim-Subscription-Key: $PJM_API_KEY"
```

ENTSO-E API shape:

```bash
curl "https://web-api.tp.entsoe.eu/api?securityToken=$ENTSOE_SECURITY_TOKEN&documentType=A65&processType=A16&outBiddingZone_Domain=10Y1001A1001A82H&periodStart=202401010000&periodEnd=202401020000"
```

## Resume Instructions

1. Read `数据收集任务/README.md` first to understand the 7-source status table.
2. If ENTSO-E replied:
   - Ask user for whether token was generated.
   - Do not request the token in chat unless the user explicitly wants to test locally.
   - Update `数据收集任务/03_entsoe_transparency/README.md` from pending to ready.
3. If PJM replied:
   - Confirm whether `PJM_API_KEY` / subscription key is visible in API Portal.
   - Update `数据收集任务/04_pjm_dataminer/README.md`.
4. For TAMU:
   - Ask user to use browser to open `https://electricgrids.engr.tamu.edu/electric-grid-test-cases/`.
   - Identify selected case(s), preferably `ACTIVSg200`, `ACTIVSg500`, `ACTIVSg2000`, `ACTIVSg10k`.
   - If a direct download URL is visible, add `wget` commands to `01_tamu_test_cases/README.md`.
5. For Zenodo:
   - Confirm exact record and desired subset with user/teacher.
   - Update `06_large_synthetic_power_grid_ml/README.md` with final file list.
6. Verify no token leakage:
   ```bash
   rg -n "(api_key|securityToken|Bearer|subscription-key|Ocp-Apim-Subscription-Key).{0,8}[A-Za-z0-9_-]{16,}" 数据收集任务 || true
   ```
   Expected: no output.

## Setup Required

- Network/browser access for TAMU, ENTSO-E, PJM, Zenodo.
- Private token transfer channel for teacher.
- Do not commit real tokens.

## Warnings

- Do not confuse PJM Data Miner with EIA's PJM regional data.
- Do not overwrite the 7 README files unless updating status or adding verified download/API commands.
- Do not print existing environment token values in responses.
- If creating scripts later, use `.env.template` with empty values and read real tokens from environment variables.
