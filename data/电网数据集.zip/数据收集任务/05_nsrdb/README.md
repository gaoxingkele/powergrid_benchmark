# `nsrdb`

## 数据源定位

NSRDB 是 NREL 的 National Solar Radiation Database，提供太阳辐照和气象变量，适合光伏预测、负荷与天气联合建模、新能源并网分析等 benchmark。

官方入口：

```text
https://developer.nrel.gov/docs/solar/nsrdb/
```

API key 注册入口：

```text
https://developer.nrel.gov/signup/
```

## 当前收集状态

- 当前环境已有 `NREL_API_KEY`。
- 历史归档中已成功拉取 NSRDB CSV。
- 本次命令行访问 NREL 站点出现 TLS 连接层失败，但历史数据和 key 已证明链路曾经可用；建议换浏览器或网络再次验证。

历史数据证据：

```text
history_archive/data-and-assets/data/paper1/raw/nsrdb/
```

已落盘城市：

- `portland_or_2022.csv`
- `chicago_il_2022.csv`
- `la_2022.csv`
- `philadelphia_pa_2022.csv`
- `houston_tx_2022.csv`
- `sacramento_ca_2022.csv`

## 是否需要账号或 token

- 需要 NREL API key。
- 当前已经具备 key，不需要重新申请。
- 交付时只写环境变量名，不在文档里写真实 key。

建议环境变量：

```bash
export NREL_API_KEY=""
```

## 示例调用方式

```bash
curl --get "https://developer.nrel.gov/api/nsrdb/v2/solar/psm3-2-2-download.csv" \
  --data-urlencode "api_key=$NREL_API_KEY" \
  --data-urlencode "wkt=POINT(-118.26 34.05)" \
  --data-urlencode "names=2022" \
  --data-urlencode "interval=60" \
  --data-urlencode "utc=false" \
  --data-urlencode "leap_day=false" \
  --data-urlencode "email=your_email@example.com" \
  --data-urlencode "attributes=ghi,dni,dhi,air_temperature,wind_speed" \
  -o la_2022_nsrdb.csv
```

## 推荐处理方式

1. 把 `NREL_API_KEY` 私下交给老师。
2. 老师根据 benchmark 选择地点、年份和变量。
3. 先拉 1 个地点 1 年做验证。
4. 再扩展多个城市或多个年份。

## 最终交付给老师

- `NREL_API_KEY` 的真实值，私下发送。
- NSRDB API 模板。
- 历史验证说明：已成功拉取 6 个城市 2022 年数据。
- 注意事项：NREL 请求通常需要 email 参数。

## 验收标准

- 老师设置 `NREL_API_KEY` 后，示例请求能保存 CSV。
- CSV 头部包含 NSRDB 元数据和辐照/气象字段。
- 文档中不出现真实 API key。
