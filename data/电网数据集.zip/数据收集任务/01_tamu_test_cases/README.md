# `tamu_test_cases`

## 数据源定位

TAMU Electric Grid Test Cases 提供 ACTIVSg 系列合成电网算例，适合潮流、OPF、N-1 安全分析、图学习、电网鲁棒性等 benchmark。

官方入口：

```text
https://electricgrids.engr.tamu.edu/electric-grid-test-cases/
```

## 当前收集状态

- 历史归档中未发现已落盘的 TAMU ACTIVSg 数据文件。
- 已确认这是网页下载型资源，不是 API token 型资源。
- 本机命令行访问该站点时偶发 TLS 连接重置，建议用浏览器操作下载页。

## 是否需要账号或 token

- 不需要 API token。
- 通常不需要注册账号。
- 下载具体 case 时可能需要填写网页登记表，例如姓名、邮箱、机构、用途。
- 这类登记一般不是审批流程，但纯脚本下载是否可行取决于下载页是否暴露静态文件直链。

## 推荐处理方式

优先让老师或我们先选小到中等规模 case，不要一开始下载最大规模：

1. `ACTIVSg200`
2. `ACTIVSg500`
3. `ACTIVSg2000`
4. `ACTIVSg10k`

如果浏览器下载管理器能看到真实文件 URL，可整理成脚本：

```bash
mkdir -p tamu_test_cases
wget -O tamu_test_cases/ACTIVSg200.zip "REAL_DOWNLOAD_URL"
wget -O tamu_test_cases/ACTIVSg2000.zip "REAL_DOWNLOAD_URL"
```

如果没有暴露直链，则交付网页操作说明，而不是 token。

## 最终交付给老师

- TAMU 入口 URL。
- 推荐 case 列表。
- 每个 case 的下载页面或真实文件直链。
- 如有直链，附 `wget` 下载命令。
- 明确说明：无需 API token，可能需要网页填写下载登记表。

## 验收标准

- 至少明确 2 个推荐 case 的获取路径。
- 能说明该数据源不需要 token。
- 如果拿到直链，脚本能下载到对应文件；如果没有直链，文档能让老师按网页步骤完成下载。
