# `pjm_dataminer`

## 数据源定位

PJM Data Miner 2 是 PJM 市场和运行数据入口，适合负荷、预测负荷、节点价格、市场运行、发电、交换等 benchmark。

网页入口：

```text
https://dataminer2.pjm.com/
```

API Portal：

```text
https://apiportal.pjm.com/
```

API base：

```text
https://api.pjm.com/api/v1/
```

## 当前收集状态

- 已注册并登录 PJM Tools 账号。
- 当前 profile 中已有多个普通 tools access，但未看到 Data Miner API subscription key。
- 已按 PJM Data Miner API Guide 要求发送邮件申请 Data Miner API access。
- 历史归档中有 EIA 的 PJM 区域数据，但没有 PJM Data Miner 本身的数据或 subscription key。

## 是否需要账号或 token

- 网页 Data Miner 2 可用于公开查看和导出部分数据。
- 程序化 API 调用需要 PJM Data Miner API subscription key。
- Non-member / Other 账号通常需要 PJM provision Data Miner API access。

建议环境变量：

```bash
export PJM_API_KEY=""
```

## 已执行申请动作

已向 PJM 发送 Data Miner API access 申请邮件。

核心申请内容包括：

```text
I confirm that the PJM Data will be used for internal business purposes only.
```

开通后，需要登录 `https://apiportal.pjm.com/`，在 profile/subscriptions 中查看 primary key 或 secondary key。

## 示例调用方式

PJM Data Miner API 支持 query string 的 subscription key：

```bash
curl "https://api.pjm.com/api/v1/load_frcstd_7_day?rowCount=50000&startRow=1&format=csv&subscription-key=$PJM_API_KEY"
```

也支持 header 形式：

```bash
curl "https://api.pjm.com/api/v1/act_sch_interchange/metadata" \
  -H "Ocp-Apim-Subscription-Key: $PJM_API_KEY"
```

## 推荐处理方式

1. 等 PJM 回复并 provision Data Miner API access。
2. 在 API Portal 中复制 subscription key。
3. 私下交给老师 `PJM_API_KEY`。
4. 先用 metadata endpoint 做 smoke test。
5. 再根据 benchmark 需要选择具体 feed，例如 load forecast、instantaneous load、LMP 等。

## 网页备选方案

如果 API key 一时无法开通，可先用网页导 CSV：

1. 打开 `https://dataminer2.pjm.com/`
2. 选择 feed。
3. 点 `Explore Data Set`。
4. 设置时间范围和筛选条件。
5. 导出 CSV。

这可以作为临时数据获取方案，但不如 API 适合自动 benchmark。

## 最终交付给老师

- `PJM_API_KEY` 的真实值，私下发送。
- API Portal 和 Data Miner 2 网页入口。
- 至少一个 metadata smoke test 请求。
- 至少一个 benchmark feed 的下载请求模板。

## 验收标准

- PJM 已回复并开通 Data Miner API access。
- 老师设置 `PJM_API_KEY` 后，metadata 请求返回 JSON。
- 文档明确区分 EIA-PJM 区域数据和 PJM Data Miner 数据。
