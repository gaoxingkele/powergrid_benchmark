# `eia_opendata`

## 数据源定位

EIA Open Data 是美国能源信息署开放数据 API，适合电力负荷、发电、区域运行、能源统计等 benchmark。

官方入口：

```text
https://www.eia.gov/opendata/
```

## 当前收集状态

- 当前环境已有 `EIA_API_KEY`。
- 历史归档中已成功调用并落盘 EIA 数据。
- 本次 smoke test 已验证 EIA API 当前可用。

历史数据证据：

```text
history_archive/data-and-assets/data/paper1/raw/eia/
```

已落盘区域包括：

- `BPAT_2022_2023`
- `CISO_2022_2023`
- `ERCO_2022_2023`
- `MISO_2022_2023`
- `PJM_2022_2023`
- `bpat_hourly`

注意：这里的 `PJM_2022_2023` 是 EIA 中的 PJM 区域数据，不等同于 PJM Data Miner 数据源。

## 是否需要账号或 token

- 需要 EIA API key。
- 当前已经具备 key，不需要重新申请。
- 交付时只写环境变量名，不在文档里写真实 key。

建议环境变量：

```bash
export EIA_API_KEY=""
```

## 示例调用方式

```bash
curl --get "https://api.eia.gov/v2/electricity/rto/region-data/data/" \
  --data-urlencode "api_key=$EIA_API_KEY" \
  --data-urlencode "frequency=hourly" \
  --data-urlencode "data[0]=value" \
  --data-urlencode "facets[respondent][]=PJM" \
  --data-urlencode "start=2024-01-01" \
  --data-urlencode "end=2024-01-02" \
  --data-urlencode "length=5000"
```

## 推荐处理方式

1. 把 `EIA_API_KEY` 私下交给老师。
2. 同时交付上面的 API 模板。
3. 如果老师 benchmark 需要复现历史数据，可参考历史目录里的区域和时间范围。
4. 后续不要把带 `api_key=` 的完整请求 URL 写入公开仓库。

## 最终交付给老师

- `EIA_API_KEY` 的真实值，私下发送。
- API endpoint 和 curl 示例。
- 历史验证说明：已成功拉取多个 RTO/BA 的 2022-2023 小时数据。

## 验收标准

- 老师设置 `EIA_API_KEY` 后，curl 示例能返回 JSON。
- 返回结果中包含 `response.data`。
- 文档中不出现真实 API key。
