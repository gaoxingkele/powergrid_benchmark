# 电网 benchmark 数据源收集总览

## 目标

本目录用于整理老师要求的 7 个电网相关数据源的获取方式。当前任务不是把所有数据文件下载后交付，而是把每个数据源背后的 API token、账号申请状态、网页下载方式和可复现调用路径整理清楚，方便老师后续直接跑 benchmark。

## 交付原则

- 不在仓库文档中写入真实 token、API key、账号密码。
- 对需要 token 的数据源，只记录环境变量名、申请入口、调用方式和当前申请状态。
- 对不需要 token 的数据源，记录网页入口、是否需要填写下载登记表、推荐下载子集和可脚本化程度。
- 历史已成功调用或落盘的数据，只作为“链路已验证”的证据，不等同于本次直接交付全量数据。

## 7 个数据源状态总表

| 编号 | 数据源 | 当前状态 | 是否需要额外账号/申请 | 当前可交付内容 |
|---|---|---|---|---|
| 1 | `tamu_test_cases` | 未发现历史落盘；入口已确认 | 不需要 token；可能需要网页填写下载登记表 | 下载入口、推荐 case、人工/脚本下载方案 |
| 2 | `eia_opendata` | 已有 key；历史成功调用并落盘 | 不需要再申请 | `EIA_API_KEY` 环境变量名、示例 API、历史验证说明 |
| 3 | `entsoe_transparency` | 已有 token；smoke test 已返回 XML | 不需要再申请 | `ENTSOE_SECURITY_TOKEN` 环境变量名、已验证 API 调用模板、Postman 文档链接 |
| 4 | `pjm_dataminer` | 已发邮件申请 Data Miner API access | 需要等待 PJM provision API subscription | 申请流程、待回 subscription key、API 调用模板 |
| 5 | `nsrdb` | 已有 NREL key；历史成功拉过 NSRDB | 不需要再申请 | `NREL_API_KEY` 环境变量名、NSRDB 下载 API 模板 |
| 6 | `large_synthetic_power_grid_ml` | 未发现历史落盘；Zenodo 入口需最终确认子集 | 不需要 token | Zenodo 下载方式、子集选择建议 |
| 7 | `acn_data` | 已有 token；历史和当前 smoke test 均可调用 | 不需要再申请 | `ACN_API_TOKEN` 环境变量名、API 使用说明 |

## 当前总体进度

- 已具备 token / key 的数据源：`eia_opendata`、`entsoe_transparency`、`nsrdb`、`acn_data`。
- 不需要 token、需要整理下载入口的数据源：`tamu_test_cases`、`large_synthetic_power_grid_ml`。
- 已发送申请、等待开通的数据源：`pjm_dataminer`。

按“老师拿到后是否可以立刻开始配置 benchmark”来算，当前可以先交付 6/7 的获取方式；剩余 1/7 等邮件回复后补充 token。

## 建议交给老师的环境变量

真实值建议通过微信、邮件或密码管理器单独发送，不写入本目录。

```bash
export EIA_API_KEY=""
export NREL_API_KEY=""
export ACN_API_TOKEN=""
export ENTSOE_SECURITY_TOKEN=""
export PJM_API_KEY=""
```

## 目录说明

- `01_tamu_test_cases/`：TAMU ACTIVSg 合成电网算例。
- `02_eia_opendata/`：美国 EIA Open Data。
- `03_entsoe_transparency/`：欧洲 ENTSO-E Transparency Platform。
- `04_pjm_dataminer/`：PJM Data Miner 2。
- `05_nsrdb/`：NREL NSRDB 太阳辐照/气象数据。
- `06_large_synthetic_power_grid_ml/`：Zenodo 大规模合成电网 ML 数据。
- `07_acn_data/`：Caltech ACN-Data EV 充电会话数据。

## 下一步

1. 等 PJM 回复后，把 `PJM_API_KEY` 私下交给老师，并更新 `04_pjm_dataminer/README.md` 的状态。
2. 浏览器打开 TAMU 页面，确认老师要的 ACTIVSg case 是否能拿到直链；有直链后可补 `wget` 下载脚本。
3. 让老师确认 Zenodo 大规模数据要下载哪些子集，避免盲目全量下载。
